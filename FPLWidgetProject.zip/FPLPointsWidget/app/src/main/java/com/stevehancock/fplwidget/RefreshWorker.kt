package com.stevehancock.fplwidget

import android.content.Context
import androidx.glance.appwidget.updateAll
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

class RefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result {
        if (WidgetStore(applicationContext).teamId == null) return Result.success()
        return try {
            FplRepository(applicationContext).refresh()
            FplWidget().updateAll(applicationContext)
            Result.success()
        } catch (_: Throwable) {
            FplWidget().updateAll(applicationContext)
            Result.retry()
        }
    }
}

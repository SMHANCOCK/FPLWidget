package com.stevehancock.fplwidget

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

class AssetCache(context: Context) {
    private val assetDir = File(context.filesDir, "fpl_club_assets").apply { mkdirs() }

    fun badgeFile(code: Int): File = File(assetDir, "badge_$code.png")
    fun shirtFile(code: Int): File = File(assetDir, "shirt_$code.png")

    fun ensureBadge(code: Int) {
        if (code <= 0) return
        val target = badgeFile(code)
        if (isUsable(target)) return
        downloadFirst(
            urls = listOf(
                "https://resources.premierleague.com/premierleague/badges/50/t$code.png",
                "https://resources.premierleague.com/premierleague/badges/t$code.png"
            ),
            target = target
        )
    }

    fun ensureShirt(code: Int, teamId: Int) {
        if (code <= 0) return
        val target = shirtFile(code)
        if (isUsable(target)) return

        // FPL has historically keyed shirt assets by the Premier League team code.
        // Team ID fallbacks are included because the static asset convention can change.
        val keys = listOf(code, teamId).filter { it > 0 }.distinct()
        val urls = buildList {
            keys.forEach { key ->
                add("https://fantasy.premierleague.com/dist/img/shirts/standard/shirt_${key}-66.png")
                add("https://fantasy.premierleague.com/dist/img/shirts/standard/shirt_${key}-110.png")
            }
        }
        downloadFirst(urls, target)
    }

    private fun isUsable(file: File): Boolean = file.exists() && file.length() > 150L

    private fun downloadFirst(urls: List<String>, target: File) {
        urls.forEach { url ->
            if (download(url, target)) return
        }
        if (target.exists() && target.length() <= 150L) target.delete()
    }

    private fun download(url: String, target: File): Boolean {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 8_000
            readTimeout = 8_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "FPLPointsWidget/2.2")
            setRequestProperty("Accept", "image/png,image/webp,image/*;q=0.8")
        }
        return try {
            if (connection.responseCode !in 200..299) return false
            val bytes = connection.inputStream.use { it.readBytes() }
            if (bytes.size <= 150) return false
            target.writeBytes(bytes)
            true
        } catch (_: Throwable) {
            false
        } finally {
            connection.disconnect()
        }
    }
}

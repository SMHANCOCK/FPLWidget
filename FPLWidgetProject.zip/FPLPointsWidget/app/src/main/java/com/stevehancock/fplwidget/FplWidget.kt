package com.stevehancock.fplwidget

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Path
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.appWidgetBackground
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.appwidget.lazy.LazyColumn
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxHeight
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FplWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val store = WidgetStore(context)
        provideContent {
            WidgetContent(context, store.teamId, store.load())
        }
    }
}

private object Ui {
    val white = ColorProvider(Color(0xFFF8FAFF))
    val green = ColorProvider(Color(0xFF00FF87))
    val red = ColorProvider(Color(0xFFFF4D73))
    val muted = ColorProvider(Color(0xFFB8C0DC))
    val muted2 = ColorProvider(Color(0xFF828CAD))
    val card = ColorProvider(Color(0xD9131943))
    val cardAlt = ColorProvider(Color(0xD9181F4D))
    val cardSoft = ColorProvider(Color(0xB91B2356))
    val line = ColorProvider(Color(0x553D4976))
    val greenSoft = ColorProvider(Color(0x3300FF87))
    val redSoft = ColorProvider(Color(0x33FF4D73))
}

@Composable
private fun WidgetContent(context: Context, teamId: Int?, snapshot: WidgetSnapshot?) {
    val size = LocalSize.current
    val editAction = actionStartActivity(ComponentName(context, MainActivity::class.java))

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(R.drawable.widget_bg), ContentScale.FillBounds)
            .appWidgetBackground()
            .cornerRadius(24.dp)
            .padding(if (size.width >= 500.dp) 10.dp else 7.dp)
    ) {
        if (teamId == null) {
            EmptyState(context, "FPL WIDGET V3", "Tap to enter your FPL Team ID.")
            return@Column
        }
        if (snapshot == null) {
            EmptyState(context, "FPL WIDGET V3", "Tap to configure or load your FPL data.")
            return@Column
        }

        Header(context, snapshot, size.width.value >= 500f, editAction)
        Spacer(GlanceModifier.height(if (size.height >= 220.dp) 6.dp else 3.dp))

        if (size.width >= 500.dp) {
            WideBody(context, snapshot, size.height.value >= 240f, editAction)
        } else if (size.width < 335.dp) {
            NarrowBody(context, snapshot, size.height.value >= 220f, editAction)
        } else {
            PhoneBody(context, snapshot, size.width.value, size.height.value, editAction)
        }
    }
}

@Composable
private fun EmptyState(context: Context, title: String, message: String) {
    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .clickable(actionStartActivity(ComponentName(context, MainActivity::class.java)))
    ) {
        Text(title, style = TextStyle(color = Ui.green, fontSize = 13.sp, fontWeight = FontWeight.Bold))
        Spacer(GlanceModifier.height(7.dp))
        Text(message, style = TextStyle(color = Ui.white, fontSize = 17.sp, fontWeight = FontWeight.Bold))
        Spacer(GlanceModifier.height(4.dp))
        Text("Opens FPL Points Widget setup.", style = TextStyle(color = Ui.muted, fontSize = 10.sp))
    }
}

@Composable
private fun Header(
    context: Context,
    snapshot: WidgetSnapshot,
    wide: Boolean,
    editAction: androidx.glance.action.Action
) {
    val movement = rankMovement(snapshot.overallRank, snapshot.previousOverallRank)
    val movementColor = movementColor(movement)
    val logoSize = if (wide) 38.dp else 27.dp

    Row(
        modifier = GlanceModifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            provider = ImageProvider(R.drawable.fpl_logo),
            contentDescription = "FPL",
            modifier = GlanceModifier.size(logoSize).clickable(editAction),
            contentScale = ContentScale.Fit
        )
        Spacer(GlanceModifier.width(if (wide) 6.dp else 3.dp))
        Column(modifier = GlanceModifier.width(if (wide) 54.dp else 34.dp)) {
            Text(
                "FPL",
                style = TextStyle(color = Ui.white, fontSize = if (wide) 20.sp else 12.sp, fontWeight = FontWeight.Bold)
            )
            Text(
                "GW${snapshot.gameweek}",
                style = TextStyle(color = Ui.muted, fontSize = if (wide) 11.sp else 8.sp, fontWeight = FontWeight.Bold)
            )
        }
        Spacer(GlanceModifier.width(if (wide) 9.dp else 4.dp))

        Column(modifier = GlanceModifier.defaultWeight().clickable(editAction)) {
            Text(
                text = compactHeaderName(snapshot.teamName, wide),
                maxLines = 1,
                style = TextStyle(color = Ui.green, fontSize = if (wide) 19.sp else 11.sp, fontWeight = FontWeight.Bold)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "Overall ${formatRank(snapshot.overallRank)}",
                    style = TextStyle(color = Ui.white, fontSize = if (wide) 11.sp else 7.sp, fontWeight = FontWeight.Bold)
                )
                Spacer(GlanceModifier.width(4.dp))
                Text(
                    text = movementText(movement, includeAmount = true),
                    style = TextStyle(color = movementColor, fontSize = if (wide) 11.sp else 7.sp, fontWeight = FontWeight.Bold)
                )
            }
        }

        Column(
            modifier = GlanceModifier.width(if (wide) 118.dp else 66.dp),
            horizontalAlignment = Alignment.End
        ) {
            Text(
                text = "${snapshot.playersDone} done • ${snapshot.playersRemaining} left",
                maxLines = 1,
                style = TextStyle(color = Ui.muted, fontSize = if (wide) 10.sp else 7.sp)
            )
            Text(
                text = "Updated ${formatTime(snapshot.updatedAt)}",
                maxLines = 1,
                style = TextStyle(color = Ui.muted2, fontSize = if (wide) 9.sp else 6.sp)
            )
        }
        Spacer(GlanceModifier.width(if (wide) 7.dp else 3.dp))
        HeaderButton("✎", Ui.white, editAction, wide)
        Spacer(GlanceModifier.width(if (wide) 6.dp else 3.dp))
        Text(
            text = "↻",
            modifier = GlanceModifier
                .background(Ui.cardSoft)
                .cornerRadius(20.dp)
                .padding(if (wide) 9.dp else 5.dp)
                .clickable(actionRunCallback<RefreshAction>()),
            style = TextStyle(color = Ui.white, fontSize = if (wide) 18.sp else 12.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
private fun HeaderButton(
    text: String,
    color: ColorProvider,
    action: androidx.glance.action.Action,
    wide: Boolean
) {
    Text(
        text = text,
        modifier = GlanceModifier
            .background(Ui.cardSoft)
            .cornerRadius(20.dp)
            .padding(if (wide) 9.dp else 5.dp)
            .clickable(action),
        style = TextStyle(color = color, fontSize = if (wide) 16.sp else 11.sp, fontWeight = FontWeight.Bold)
    )
}

@Composable
private fun WideBody(
    context: Context,
    snapshot: WidgetSnapshot,
    tall: Boolean,
    editAction: androidx.glance.action.Action
) {
    Row(modifier = GlanceModifier.fillMaxSize()) {
        Column(modifier = GlanceModifier.defaultWeight().fillMaxHeight()) {
            MetricsRow(context, snapshot, wide = true, editAction = editAction)
            Spacer(GlanceModifier.height(7.dp))
            FixtureSection(context, snapshot, maxCards = 7, wide = true, modifier = GlanceModifier.defaultWeight())
        }
        Spacer(GlanceModifier.width(8.dp))
        LeagueCard(
            snapshot = snapshot,
            modifier = GlanceModifier.width(if (tall) 250.dp else 225.dp).fillMaxHeight(),
            wide = true,
            context = context
        )
    }
}

@Composable
private fun PhoneBody(
    context: Context,
    snapshot: WidgetSnapshot,
    widthDp: Float,
    heightDp: Float,
    editAction: androidx.glance.action.Action
) {
    // Give the league enough real estate to be readable on a phone. Fewer rows are
    // visible at once, but the LazyColumn remains genuinely vertically scrollable.
    val leagueWidth = when {
        widthDp >= 420f -> 170.dp
        widthDp >= 390f -> 162.dp
        widthDp >= 365f -> 154.dp
        else -> 142.dp
    }
    val maxFixtures = 3
    val taller = heightDp >= 205f

    Row(modifier = GlanceModifier.fillMaxSize()) {
        Column(modifier = GlanceModifier.defaultWeight().fillMaxHeight()) {
            MetricsRow(context, snapshot, wide = false, editAction = editAction)
            Spacer(GlanceModifier.height(4.dp))
            FixtureSection(
                context = context,
                snapshot = snapshot,
                maxCards = maxFixtures,
                wide = false,
                modifier = GlanceModifier.defaultWeight()
            )
        }
        Spacer(GlanceModifier.width(5.dp))
        LeagueCard(
            snapshot = snapshot,
            modifier = GlanceModifier.width(leagueWidth).fillMaxHeight(),
            wide = false,
            context = context,
            roomy = taller
        )
    }
}

@Composable
private fun NarrowBody(
    context: Context,
    snapshot: WidgetSnapshot,
    tall: Boolean,
    editAction: androidx.glance.action.Action
) {
    Column(modifier = GlanceModifier.fillMaxSize()) {
        MetricsRow(context, snapshot, wide = false, editAction = editAction)
        Spacer(GlanceModifier.height(4.dp))
        FixtureSection(context, snapshot, maxCards = 4, wide = false, modifier = GlanceModifier.defaultWeight())
        if (tall) {
            Spacer(GlanceModifier.height(4.dp))
            LeagueCompact(snapshot, context)
        }
    }
}

@Composable
private fun MetricsRow(
    context: Context,
    snapshot: WidgetSnapshot,
    wide: Boolean,
    editAction: androidx.glance.action.Action
) {
    Row(modifier = GlanceModifier.fillMaxWidth()) {
        ScoreCard(snapshot, wide)
        Spacer(GlanceModifier.width(if (wide) 7.dp else 3.dp))
        AverageCard(snapshot, wide)
        Spacer(GlanceModifier.width(if (wide) 7.dp else 3.dp))
        DifferenceCard(snapshot, wide)
        Spacer(GlanceModifier.width(if (wide) 7.dp else 3.dp))
        CaptainCard(context, snapshot, wide, editAction, GlanceModifier.defaultWeight())
    }
}

@Composable
private fun ScoreCard(snapshot: WidgetSnapshot, wide: Boolean) {
    Column(
        modifier = GlanceModifier
            .width(if (wide) 136.dp else 61.dp)
            .height(if (wide) 118.dp else 72.dp)
            .background(Ui.card)
            .cornerRadius(16.dp)
            .padding(if (wide) 10.dp else 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = snapshot.livePoints.toString(),
            maxLines = 1,
            style = TextStyle(color = Ui.white, fontSize = if (wide) 62.sp else 37.sp, fontWeight = FontWeight.Bold)
        )
        Text(
            text = "PTS",
            maxLines = 1,
            style = TextStyle(color = Ui.white, fontSize = if (wide) 12.sp else 7.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
private fun AverageCard(snapshot: WidgetSnapshot, wide: Boolean) {
    MetricCard(
        title = "Average",
        value = snapshot.averagePoints.toString(),
        valueColor = Ui.white,
        wide = wide,
        width = if (wide) 78.dp else 42.dp
    )
}

@Composable
private fun DifferenceCard(snapshot: WidgetSnapshot, wide: Boolean) {
    val diff = snapshot.livePoints - snapshot.averagePoints
    MetricCard(
        title = "vs Average",
        value = if (diff > 0) "+$diff" else diff.toString(),
        valueColor = when {
            diff > 0 -> Ui.green
            diff < 0 -> Ui.red
            else -> Ui.muted
        },
        wide = wide,
        width = if (wide) 96.dp else 46.dp
    )
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    valueColor: ColorProvider,
    wide: Boolean,
    width: androidx.compose.ui.unit.Dp
) {
    Column(
        modifier = GlanceModifier
            .width(width)
            .height(if (wide) 118.dp else 72.dp)
            .background(Ui.cardAlt)
            .cornerRadius(16.dp)
            .padding(if (wide) 9.dp else 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            maxLines = 1,
            style = TextStyle(color = Ui.muted, fontSize = if (wide) 11.sp else 6.sp)
        )
        Spacer(GlanceModifier.height(if (wide) 8.dp else 3.dp))
        Text(
            text = value,
            maxLines = 1,
            style = TextStyle(color = valueColor, fontSize = if (wide) 34.sp else 18.sp, fontWeight = FontWeight.Bold)
        )
        Text(
            text = "PTS",
            style = TextStyle(color = Ui.muted, fontSize = if (wide) 10.sp else 6.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
private fun CaptainCard(
    context: Context,
    snapshot: WidgetSnapshot,
    wide: Boolean,
    editAction: androidx.glance.action.Action,
    modifier: GlanceModifier
) {
    Column(
        modifier = modifier
            .height(if (wide) 118.dp else 72.dp)
            .background(Ui.cardAlt)
            .cornerRadius(16.dp)
            .padding(if (wide) 8.dp else 3.dp)
            .clickable(editAction),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "Captain",
                style = TextStyle(color = Ui.muted, fontSize = if (wide) 11.sp else 6.sp)
            )
            Spacer(GlanceModifier.width(3.dp))
            Text(
                text = if (snapshot.captainMultiplier >= 3) "TC" else "C",
                modifier = GlanceModifier.background(Ui.white).cornerRadius(10.dp).padding(3.dp),
                style = TextStyle(color = ColorProvider(Color(0xFF11162F)), fontSize = if (wide) 8.sp else 5.sp, fontWeight = FontWeight.Bold)
            )
        }

        // Keep the title at the top but drop the visual captain content slightly so
        // the captain points line finishes on the same baseline as the PTS labels
        // in the neighbouring score/average cards.
        Spacer(GlanceModifier.height(if (wide) 10.dp else 4.dp))

        val shirt = loadBitmap(AssetCache(context).shirtFile(snapshot.captainTeamCode))
            ?: createKitBitmap(snapshot.captainTeamShort)
        Image(
            provider = ImageProvider(shirt),
            contentDescription = "${snapshot.captainName} kit",
            modifier = GlanceModifier.size(if (wide) 40.dp else 20.dp),
            contentScale = ContentScale.Fit
        )
        Text(
            text = compactName(snapshot.captainName, if (wide) 12 else 8),
            maxLines = 1,
            style = TextStyle(color = Ui.white, fontSize = if (wide) 11.sp else 6.sp, fontWeight = FontWeight.Bold)
        )
        Text(
            text = "${snapshot.captainPoints} PTS",
            maxLines = 1,
            style = TextStyle(color = Ui.white, fontSize = if (wide) 10.sp else 6.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
private fun FixtureSection(
    context: Context,
    snapshot: WidgetSnapshot,
    maxCards: Int,
    wide: Boolean,
    modifier: GlanceModifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Ui.cardSoft)
            .cornerRadius(15.dp)
            .padding(if (wide) 8.dp else 4.dp)
    ) {
        Text(
            text = "Players by fixture",
            style = TextStyle(color = Ui.white, fontSize = if (wide) 12.sp else 7.sp, fontWeight = FontWeight.Bold)
        )
        Spacer(GlanceModifier.height(if (wide) 5.dp else 2.dp))

        if (snapshot.fixtures.isEmpty()) {
            Text(
                text = if (snapshot.playersRemaining == 0) "All scoring players finished" else "Fixture data loading…",
                style = TextStyle(color = Ui.muted, fontSize = if (wide) 10.sp else 7.sp)
            )
            return@Column
        }

        // Unfinished fixtures first. Within each state, the latest kickoff appears
        // first so the most relevant/upcoming action stays at the top of the list.
        val fixtures = snapshot.fixtures.sortedWith(
            compareBy<FixtureCard> { it.finished }
                .thenByDescending { it.kickoffAt }
        )

        // A Glance LazyColumn maps to a real scrollable widget collection. This
        // replaces the previous left/right paging controls and gives the launcher
        // a native vertical scrollbar when there is more content than fits.
        LazyColumn(
            modifier = GlanceModifier
                .defaultWeight()
                .fillMaxWidth()
        ) {
            items(fixtures.size) { index ->
                FixtureRowView(context, fixtures[index], wide)
            }
        }
    }
}

@Composable
private fun FixtureRowView(
    context: Context,
    fixture: FixtureCard,
    wide: Boolean
) {
    val countBackground = if (fixture.finished) Ui.line else Ui.green
    val countText = if (fixture.finished) Ui.white else ColorProvider(Color(0xFF07172B))

    Row(
        modifier = GlanceModifier
            .fillMaxWidth()
            .background(Ui.cardAlt)
            .cornerRadius(11.dp)
            .padding(if (wide) 5.dp else 3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ClubBadge(context, fixture.teamCode, fixture.teamShort, if (wide) 26.dp else 17.dp)
        Spacer(GlanceModifier.width(if (wide) 7.dp else 4.dp))

        Text(
            text = fixture.teamShort,
            modifier = GlanceModifier.width(if (wide) 38.dp else 26.dp),
            maxLines = 1,
            style = TextStyle(color = Ui.white, fontSize = if (wide) 10.sp else 6.sp, fontWeight = FontWeight.Bold)
        )

        Text(
            text = "v ${fixture.opponentShort} (${fixture.homeAway})",
            modifier = GlanceModifier.defaultWeight(),
            maxLines = 1,
            style = TextStyle(color = Ui.muted, fontSize = if (wide) 9.sp else 5.sp)
        )

        Text(
            text = fixture.count.toString(),
            modifier = GlanceModifier
                .width(if (wide) 42.dp else 28.dp)
                .background(countBackground)
                .cornerRadius(12.dp)
                .padding(if (wide) 4.dp else 2.dp),
            style = TextStyle(
                color = countText,
                fontSize = if (wide) 10.sp else 6.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        )

        Spacer(GlanceModifier.width(if (wide) 7.dp else 4.dp))
        Column(
            modifier = GlanceModifier.width(if (wide) 66.dp else 43.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Text(
                text = formatFixtureDate(fixture.kickoffAt),
                maxLines = 1,
                style = TextStyle(color = Ui.muted, fontSize = if (wide) 7.sp else 4.sp)
            )
            Text(
                text = formatFixtureTime(fixture.kickoffAt),
                maxLines = 1,
                style = TextStyle(color = Ui.muted, fontSize = if (wide) 7.sp else 4.sp)
            )
        }
    }
    Spacer(GlanceModifier.height(if (wide) 3.dp else 2.dp))
}

@Composable
private fun ClubBadge(context: Context, code: Int, fallback: String, badgeSize: androidx.compose.ui.unit.Dp) {
    val bitmap = if (code > 0) loadBitmap(AssetCache(context).badgeFile(code)) else null
    if (bitmap != null) {
        Image(
            provider = ImageProvider(bitmap),
            contentDescription = fallback,
            modifier = GlanceModifier.size(badgeSize),
            contentScale = ContentScale.Fit
        )
    } else {
        Text(
            text = fallback.take(3),
            modifier = GlanceModifier.background(Ui.cardSoft).cornerRadius(9.dp).padding(2.dp),
            style = TextStyle(color = Ui.muted, fontSize = 6.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
private fun LeagueCard(
    snapshot: WidgetSnapshot,
    modifier: GlanceModifier,
    wide: Boolean,
    context: Context,
    roomy: Boolean = true
) {
    val leagueAction = actionStartActivity(ComponentName(context, LeagueActivity::class.java))
    Column(
        modifier = modifier
            .background(Ui.cardAlt)
            .cornerRadius(16.dp)
            .padding(if (wide) 8.dp else 4.dp)
    ) {
        Row(modifier = GlanceModifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = GlanceModifier.defaultWeight().clickable(leagueAction)) {
                Text(
                    text = compactLeagueName(snapshot.leagueName, if (wide) 22 else 13),
                    maxLines = 1,
                    style = TextStyle(color = Ui.white, fontSize = if (wide) 13.sp else 9.sp, fontWeight = FontWeight.Bold)
                )
                if (snapshot.leagueUsesLiveScores) {
                    Text("LIVE standings", style = TextStyle(color = Ui.green, fontSize = if (wide) 7.sp else 5.sp, fontWeight = FontWeight.Bold))
                }
            }
            Text("›", style = TextStyle(color = Ui.muted, fontSize = if (wide) 18.sp else 9.sp, fontWeight = FontWeight.Bold))
        }
        Spacer(GlanceModifier.height(if (wide) 5.dp else 2.dp))
        LeagueHeader(wide)
        Spacer(GlanceModifier.height(1.dp))

        if (snapshot.leagueStandings.isEmpty()) {
            Text(
                text = "League data loads on refresh",
                modifier = GlanceModifier.defaultWeight(),
                style = TextStyle(color = Ui.muted, fontSize = if (wide) 9.sp else 6.sp)
            )
        } else {
            LazyColumn(modifier = GlanceModifier.defaultWeight().fillMaxWidth()) {
                items(snapshot.leagueStandings.size) { index ->
                    LeagueRow(snapshot.leagueStandings[index], wide, roomy)
                }
            }
        }

        Spacer(GlanceModifier.height(2.dp))
        Text(
            text = if (wide) "👥  View full league   ›" else "View league  ›",
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(Ui.cardSoft)
                .cornerRadius(12.dp)
                .padding(if (wide) 6.dp else 3.dp)
                .clickable(leagueAction),
            style = TextStyle(
                color = Ui.muted,
                fontSize = if (wide) 9.sp else 5.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        )
    }
}

@Composable
private fun LeagueHeader(wide: Boolean) {
    Row(modifier = GlanceModifier.fillMaxWidth()) {
        Text("#", modifier = GlanceModifier.width(if (wide) 22.dp else 16.dp), style = TextStyle(color = Ui.muted, fontSize = if (wide) 8.sp else 6.sp, fontWeight = FontWeight.Bold))
        Text("Team", modifier = GlanceModifier.defaultWeight(), style = TextStyle(color = Ui.muted, fontSize = if (wide) 8.sp else 6.sp, fontWeight = FontWeight.Bold))
        Text("GW", modifier = GlanceModifier.width(if (wide) 32.dp else 24.dp), style = TextStyle(color = Ui.muted, fontSize = if (wide) 8.sp else 6.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End))
        Text("Total", modifier = GlanceModifier.width(if (wide) 38.dp else 31.dp), style = TextStyle(color = Ui.muted, fontSize = if (wide) 8.sp else 6.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End))
        Spacer(GlanceModifier.width(if (wide) 18.dp else 12.dp))
    }
}

@Composable
private fun LeagueRow(row: LeagueStanding, wide: Boolean, roomy: Boolean) {
    val movement = rankMovement(row.rank, row.lastRank)
    val movementColor = movementColor(movement)
    Row(
        modifier = GlanceModifier
            .fillMaxWidth()
            .background(if (row.isUser) Ui.greenSoft else ColorProvider(Color.Transparent))
            .cornerRadius(if (row.isUser) 8.dp else 0.dp)
            .padding(if (wide) 4.dp else if (roomy) 3.dp else 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            row.rank.toString(),
            modifier = GlanceModifier.width(if (wide) 22.dp else 16.dp),
            style = TextStyle(color = Ui.white, fontSize = if (wide) 8.sp else 7.sp, fontWeight = if (row.isUser) FontWeight.Bold else FontWeight.Normal)
        )
        Text(
            compactName(row.teamName, if (wide) 22 else 15),
            modifier = GlanceModifier.defaultWeight(),
            maxLines = 1,
            style = TextStyle(color = Ui.white, fontSize = if (wide) 8.sp else 7.sp, fontWeight = if (row.isUser) FontWeight.Bold else FontWeight.Normal)
        )
        Text(
            row.eventPoints.toString(),
            modifier = GlanceModifier.width(if (wide) 32.dp else 24.dp),
            style = TextStyle(color = Ui.white, fontSize = if (wide) 8.sp else 7.sp, textAlign = TextAlign.End)
        )
        Text(
            row.totalPoints.toString(),
            modifier = GlanceModifier.width(if (wide) 38.dp else 31.dp),
            style = TextStyle(color = Ui.white, fontSize = if (wide) 8.sp else 7.sp, textAlign = TextAlign.End)
        )
        Text(
            movementText(movement, includeAmount = false),
            modifier = GlanceModifier.width(if (wide) 18.dp else 12.dp),
            style = TextStyle(color = movementColor, fontSize = if (wide) 8.sp else 7.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        )
    }
}

@Composable
private fun LeagueCompact(snapshot: WidgetSnapshot, context: Context) {
    val action = actionStartActivity(ComponentName(context, LeagueActivity::class.java))
    Row(
        modifier = GlanceModifier.fillMaxWidth().background(Ui.cardAlt).cornerRadius(12.dp).padding(5.dp).clickable(action),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(compactLeagueName(snapshot.leagueName, 18), modifier = GlanceModifier.defaultWeight(), style = TextStyle(color = Ui.white, fontSize = 8.sp, fontWeight = FontWeight.Bold))
        Text(ordinal(snapshot.leagueRank), style = TextStyle(color = Ui.green, fontSize = 10.sp, fontWeight = FontWeight.Bold))
        Text("  ›", style = TextStyle(color = Ui.muted, fontSize = 10.sp))
    }
}

class RefreshAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: androidx.glance.action.ActionParameters
    ) {
        try {
            FplRepository(context).refresh()
        } catch (_: Throwable) {
            // Keep the last good snapshot visible if the API is temporarily unavailable.
        }
        FplWidget().update(context, glanceId)
    }
}

private fun loadBitmap(file: java.io.File): Bitmap? = try {
    if (!file.exists() || file.length() <= 150L) null else BitmapFactory.decodeFile(file.absolutePath)
} catch (_: Throwable) {
    null
}

private fun createKitBitmap(teamShort: String): Bitmap {
    val bitmap = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val (body, accent) = kitColours(teamShort)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = body }
    val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent }
    val shirt = Path().apply {
        moveTo(23f, 15f); lineTo(31f, 10f); lineTo(41f, 10f); lineTo(49f, 15f)
        lineTo(63f, 23f); lineTo(55f, 37f); lineTo(48f, 33f); lineTo(48f, 63f)
        lineTo(24f, 63f); lineTo(24f, 33f); lineTo(17f, 37f); lineTo(9f, 23f); close()
    }
    canvas.drawPath(shirt, paint)
    canvas.drawRect(24f, 20f, 48f, 25f, accentPaint)
    canvas.drawCircle(36f, 12f, 5f, accentPaint)
    return bitmap
}

private fun kitColours(teamShortRaw: String): Pair<Int, Int> {
    return when (teamShortRaw.uppercase(Locale.UK)) {
        "ARS" -> AndroidColor.rgb(219, 0, 7) to AndroidColor.WHITE
        "AVL" -> AndroidColor.rgb(103, 14, 54) to AndroidColor.rgb(149, 191, 229)
        "BOU" -> AndroidColor.rgb(218, 41, 28) to AndroidColor.rgb(20, 20, 20)
        "BRE" -> AndroidColor.rgb(228, 0, 43) to AndroidColor.WHITE
        "BHA" -> AndroidColor.rgb(0, 87, 184) to AndroidColor.WHITE
        "BUR" -> AndroidColor.rgb(108, 29, 69) to AndroidColor.rgb(153, 204, 255)
        "CHE" -> AndroidColor.rgb(3, 70, 148) to AndroidColor.WHITE
        "CRY" -> AndroidColor.rgb(27, 69, 143) to AndroidColor.rgb(196, 18, 48)
        "EVE" -> AndroidColor.rgb(0, 51, 153) to AndroidColor.WHITE
        "FUL" -> AndroidColor.WHITE to AndroidColor.rgb(20, 20, 20)
        "LEE" -> AndroidColor.WHITE to AndroidColor.rgb(255, 205, 0)
        "LIV" -> AndroidColor.rgb(200, 16, 46) to AndroidColor.WHITE
        "MCI" -> AndroidColor.rgb(108, 171, 221) to AndroidColor.WHITE
        "MUN" -> AndroidColor.rgb(218, 41, 28) to AndroidColor.rgb(255, 205, 0)
        "NEW" -> AndroidColor.rgb(30, 30, 30) to AndroidColor.WHITE
        "NFO" -> AndroidColor.rgb(221, 0, 0) to AndroidColor.WHITE
        "SUN" -> AndroidColor.rgb(235, 23, 40) to AndroidColor.WHITE
        "TOT" -> AndroidColor.WHITE to AndroidColor.rgb(19, 34, 87)
        "WHU" -> AndroidColor.rgb(122, 38, 58) to AndroidColor.rgb(27, 177, 231)
        "WOL" -> AndroidColor.rgb(253, 185, 19) to AndroidColor.rgb(35, 31, 32)
        else -> AndroidColor.rgb(45, 74, 255) to AndroidColor.WHITE
    }
}

private fun movementColor(movement: Int): ColorProvider = when {
    movement > 0 -> Ui.green
    movement < 0 -> Ui.red
    else -> Ui.muted
}

private fun movementText(movement: Int, includeAmount: Boolean): String = when {
    movement > 0 -> if (includeAmount) "▲ ${formatRank(movement)}" else "▲"
    movement < 0 -> if (includeAmount) "▼ ${formatRank(-movement)}" else "▼"
    else -> "•"
}

private fun rankMovement(current: Int, previous: Int): Int {
    if (current <= 0 || previous <= 0) return 0
    return previous - current
}

private fun formatRank(value: Int): String =
    if (value <= 0) "-" else NumberFormat.getIntegerInstance(Locale.UK).format(value)

private fun formatTime(epoch: Long): String {
    if (epoch <= 0L) return "-"
    return SimpleDateFormat("HH:mm", Locale.UK).format(Date(epoch))
}

private fun formatFixtureDate(epoch: Long): String {
    if (epoch <= 0L) return "-"
    return SimpleDateFormat("EEE d MMM", Locale.UK).format(Date(epoch))
}

private fun formatFixtureTime(epoch: Long): String {
    if (epoch <= 0L) return "-"
    return SimpleDateFormat("HH:mm", Locale.UK).format(Date(epoch))
}

private fun compactHeaderName(value: String, wide: Boolean): String {
    val max = if (wide) 28 else 17
    val upper = value.uppercase(Locale.UK)
    return if (upper.length <= max) upper else upper.take(max - 1) + "…"
}

private fun compactName(value: String, max: Int): String =
    if (value.length <= max) value else value.take((max - 1).coerceAtLeast(1)) + "…"

private fun compactLeagueName(value: String, max: Int): String {
    val clean = if (value.isBlank()) "Your League" else value
    return compactName(clean, max)
}

private fun ordinal(value: Int): String {
    if (value <= 0) return "-"
    val mod100 = value % 100
    val suffix = if (mod100 in 11..13) "th" else when (value % 10) {
        1 -> "st"
        2 -> "nd"
        3 -> "rd"
        else -> "th"
    }
    return "$value$suffix"
}

package com.stevehancock.fplwidget

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Path
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.appWidgetBackground
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.size
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FplWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val store = WidgetStore(context)
        provideContent {
            WidgetContent(context, store.teamId, store.load())
        }
    }
}

@Composable
private fun WidgetContent(context: Context, teamId: Int?, snapshot: WidgetSnapshot?) {
    val white = ColorProvider(Color(0xFFF8FAFF))
    val green = ColorProvider(Color(0xFF00FF87))
    val red = ColorProvider(Color(0xFFFF5E77))
    val muted = ColorProvider(Color(0xFFB8C0E0))
    val muted2 = ColorProvider(Color(0xFF8E98C4))
    val card = ColorProvider(Color(0xAA121B59))
    val cardPurple = ColorProvider(Color(0xAA271B73))
    val line = ColorProvider(Color(0x554A65D6))
    val editAction = actionStartActivity(ComponentName(context, MainActivity::class.java))

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(R.drawable.widget_bg), ContentScale.FillBounds)
            .appWidgetBackground()
            .cornerRadius(24.dp)
            .padding(8.dp)
    ) {
        if (teamId == null) {
            EmptyState(
                context = context,
                title = "FPL WIDGET V2.2",
                message = "Tap here to enter your FPL Team ID."
            )
            return@Column
        }

        if (snapshot == null) {
            EmptyState(
                context = context,
                title = "FPL WIDGET V2.2",
                message = "Tap here to configure or load your live data."
            )
            Spacer(GlanceModifier.height(6.dp))
            Text(
                text = "↻  Refresh",
                modifier = GlanceModifier
                    .background(cardPurple)
                    .cornerRadius(14.dp)
                    .padding(6.dp)
                    .clickable(actionRunCallback<RefreshAction>()),
                style = TextStyle(color = green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            )
            return@Column
        }

        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Image(
                provider = ImageProvider(R.drawable.fpl_logo),
                contentDescription = "Premier League",
                modifier = GlanceModifier
                    .size(24.dp)
                    .clickable(editAction),
                contentScale = ContentScale.Fit
            )
            Spacer(GlanceModifier.width(4.dp))
            Text(
                text = "GW${snapshot.gameweek} -",
                style = TextStyle(color = green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(GlanceModifier.width(4.dp))
            Text(
                text = compactTeamName(snapshot.teamName),
                modifier = GlanceModifier
                    .defaultWeight()
                    .clickable(editAction),
                style = TextStyle(color = white, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            )
            Text(
                text = "${snapshot.playersDone} done • ${snapshot.playersRemaining} left",
                style = TextStyle(color = muted, fontSize = 8.sp)
            )
            Spacer(GlanceModifier.width(4.dp))
            Text(
                text = "✎",
                modifier = GlanceModifier
                    .background(ColorProvider(Color(0x332B3D85)))
                    .cornerRadius(13.dp)
                    .padding(5.dp)
                    .clickable(editAction),
                style = TextStyle(color = muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(GlanceModifier.width(3.dp))
            Text(
                text = "↻",
                modifier = GlanceModifier
                    .background(ColorProvider(Color(0x442B3D85)))
                    .cornerRadius(14.dp)
                    .padding(5.dp)
                    .clickable(actionRunCallback<RefreshAction>()),
                style = TextStyle(color = white, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            )
        }

        Spacer(GlanceModifier.height(4.dp))

        Row(modifier = GlanceModifier.fillMaxWidth()) {
            LeftScoreColumn(context, snapshot, white, green, red, muted, card, line, editAction)
            Spacer(GlanceModifier.width(5.dp))
            RemainingColumn(context, snapshot, white, muted, muted2, card, line, GlanceModifier.defaultWeight())
            Spacer(GlanceModifier.width(5.dp))
            RankColumn(snapshot, white, green, red, muted, cardPurple)
        }
    }
}

@Composable
private fun EmptyState(context: Context, title: String, message: String) {
    val white = ColorProvider(Color.White)
    val green = ColorProvider(Color(0xFF00FF87))
    val muted = ColorProvider(Color(0xFFB8C0E0))

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .clickable(actionStartActivity(ComponentName(context, MainActivity::class.java)))
    ) {
        Text(
            text = title,
            style = TextStyle(color = green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        )
        Spacer(GlanceModifier.height(6.dp))
        Text(
            text = message,
            style = TextStyle(color = white, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        )
        Spacer(GlanceModifier.height(4.dp))
        Text(
            text = "Opens FPL Points Widget setup.",
            style = TextStyle(color = muted, fontSize = 10.sp)
        )
    }
}

@Composable
private fun LeftScoreColumn(
    context: Context,
    snapshot: WidgetSnapshot,
    white: ColorProvider,
    green: ColorProvider,
    red: ColorProvider,
    muted: ColorProvider,
    card: ColorProvider,
    line: ColorProvider,
    editAction: androidx.glance.action.Action
) {
    Column(modifier = GlanceModifier.width(112.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = GlanceModifier.width(68.dp)) {
                Text(
                    text = snapshot.livePoints.toString(),
                    style = TextStyle(color = white, fontSize = 42.sp, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "LIVE POINTS",
                    style = TextStyle(color = white, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                )
            }
            Spacer(
                modifier = GlanceModifier
                    .width(1.dp)
                    .height(54.dp)
                    .background(line)
            )
            Spacer(GlanceModifier.width(6.dp))
            Column {
                Text(
                    text = "Avg ${snapshot.averagePoints}",
                    style = TextStyle(color = white, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                )
                Spacer(GlanceModifier.height(3.dp))
                val diff = snapshot.livePoints - snapshot.averagePoints
                val diffColor = if (diff >= 0) green else red
                val diffPrefix = if (diff >= 0) "▲ +" else "▼ "
                Text(
                    text = "$diffPrefix$diff",
                    modifier = GlanceModifier
                        .background(ColorProvider(if (diff >= 0) Color(0x3324FF9D) else Color(0x33FF5E77)))
                        .cornerRadius(12.dp)
                        .padding(4.dp),
                    style = TextStyle(color = diffColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "vs avg",
                    style = TextStyle(color = muted, fontSize = 7.sp)
                )
            }
        }

        Spacer(GlanceModifier.height(2.dp))
        Text(
            text = "Updated ${formatTime(snapshot.updatedAt)}",
            style = TextStyle(color = muted, fontSize = 7.sp)
        )
        Spacer(GlanceModifier.height(4.dp))

        Row(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(card)
                .cornerRadius(11.dp)
                .padding(5.dp)
                .clickable(editAction),
            verticalAlignment = Alignment.CenterVertically
        ) {
            CaptainKit(context, snapshot, white)
            Spacer(GlanceModifier.width(5.dp))
            Column(modifier = GlanceModifier.defaultWeight()) {
                val capSuffix = if (snapshot.captainMultiplier >= 3) " (TC)" else " (C)"
                Text(
                    text = "Captain: ${compactName(snapshot.captainName)}$capSuffix",
                    style = TextStyle(color = white, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${snapshot.captainPoints} pts",
                    style = TextStyle(color = muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                )
            }
        }
    }
}

@Composable
private fun CaptainKit(context: Context, snapshot: WidgetSnapshot, white: ColorProvider) {
    val cached = loadBitmap(AssetCache(context).shirtFile(snapshot.captainTeamCode))
    val bitmap = cached ?: createKitBitmap(snapshot.captainTeamShort)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            provider = ImageProvider(bitmap),
            contentDescription = snapshot.captainTeamShort.ifBlank { "Captain kit" },
            modifier = GlanceModifier.size(25.dp),
            contentScale = ContentScale.Fit
        )
        Text(
            text = if (snapshot.captainMultiplier >= 3) "TC" else "C",
            modifier = GlanceModifier
                .background(ColorProvider(Color(0xFFF4F5FB)))
                .cornerRadius(9.dp)
                .padding(3.dp),
            style = TextStyle(color = ColorProvider(Color(0xFF10142F)), fontSize = 7.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
private fun RemainingColumn(
    context: Context,
    snapshot: WidgetSnapshot,
    white: ColorProvider,
    muted: ColorProvider,
    muted2: ColorProvider,
    card: ColorProvider,
    line: ColorProvider,
    modifier: GlanceModifier
) {
    Column(
        modifier = modifier
            .background(card)
            .cornerRadius(12.dp)
            .padding(6.dp)
    ) {
        Row(modifier = GlanceModifier.fillMaxWidth()) {
            Text(
                text = "Remaining",
                modifier = GlanceModifier.defaultWeight(),
                style = TextStyle(color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            )
            Text(
                text = "›",
                style = TextStyle(color = muted, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            )
        }
        Spacer(GlanceModifier.height(2.dp))

        val rows = snapshot.remainingFixtures.take(3)
        if (rows.isEmpty()) {
            Text(
                text = if (snapshot.playersRemaining == 0) "All players finished" else "Fixtures loading...",
                style = TextStyle(color = muted2, fontSize = 8.sp)
            )
        } else {
            rows.forEachIndexed { index, fixture ->
                FixtureRow(context, fixture, white, muted)
                if (index < rows.lastIndex) {
                    Spacer(
                        modifier = GlanceModifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(line)
                    )
                }
            }
            if (snapshot.remainingFixtures.size > 3) {
                Text(
                    text = "+${snapshot.remainingFixtures.size - 3} more",
                    style = TextStyle(color = muted2, fontSize = 7.sp)
                )
            }
        }
    }
}

@Composable
private fun FixtureRow(
    context: Context,
    fixture: RemainingFixture,
    white: ColorProvider,
    muted: ColorProvider
) {
    Row(
        modifier = GlanceModifier.fillMaxWidth().padding(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ClubBadge(context, fixture.homeCode, fixture.homeShort, muted)
        Spacer(GlanceModifier.width(2.dp))
        ClubBadge(context, fixture.awayCode, fixture.awayShort, muted)
        Spacer(GlanceModifier.width(4.dp))
        Text(
            text = fixture.label,
            modifier = GlanceModifier.defaultWeight(),
            style = TextStyle(color = muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
        )
        Text(
            text = fixture.count.toString(),
            style = TextStyle(color = white, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
private fun ClubBadge(context: Context, code: Int, fallback: String, muted: ColorProvider) {
    val bitmap = if (code > 0) loadBitmap(AssetCache(context).badgeFile(code)) else null
    if (bitmap != null) {
        Image(
            provider = ImageProvider(bitmap),
            contentDescription = fallback,
            modifier = GlanceModifier.size(16.dp),
            contentScale = ContentScale.Fit
        )
    } else {
        Text(
            text = fallback.take(3),
            modifier = GlanceModifier
                .background(ColorProvider(Color(0x332D4AFF)))
                .cornerRadius(8.dp)
                .padding(2.dp),
            style = TextStyle(color = muted, fontSize = 6.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
private fun RankColumn(
    snapshot: WidgetSnapshot,
    white: ColorProvider,
    green: ColorProvider,
    red: ColorProvider,
    muted: ColorProvider,
    cardPurple: ColorProvider
) {
    Column(modifier = GlanceModifier.width(124.dp)) {
        Column(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(cardPurple)
                .cornerRadius(12.dp)
                .padding(6.dp)
        ) {
            Text(
                text = "Overall Rank  ▥",
                style = TextStyle(color = muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            )
            Text(
                text = formatRank(snapshot.overallRank),
                style = TextStyle(color = white, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            )
            val movement = rankMovement(snapshot.overallRank, snapshot.previousOverallRank)
            val movementColor = when {
                movement > 0 -> green
                movement < 0 -> red
                else -> muted
            }
            val movementText = when {
                movement > 0 -> "▲ ${formatRank(movement)}"
                movement < 0 -> "▼ ${formatRank(-movement)}"
                else -> "—"
            }
            Text(
                text = movementText,
                style = TextStyle(color = movementColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Last: ${formatRank(snapshot.previousOverallRank)}",
                style = TextStyle(color = muted, fontSize = 7.sp)
            )
        }

        Spacer(GlanceModifier.height(4.dp))

        Column(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(cardPurple)
                .cornerRadius(12.dp)
                .padding(6.dp)
        ) {
            Text(
                text = compactLeagueName(snapshot.leagueName),
                style = TextStyle(color = muted, fontSize = 8.sp, fontWeight = FontWeight.Bold)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = ordinal(snapshot.leagueRank),
                    modifier = GlanceModifier.defaultWeight(),
                    style = TextStyle(color = white, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                )
                val movement = rankMovement(snapshot.leagueRank, snapshot.leagueLastRank)
                val movementColor = when {
                    movement > 0 -> green
                    movement < 0 -> red
                    else -> muted
                }
                val movementText = when {
                    movement > 0 -> "▲$movement"
                    movement < 0 -> "▼${-movement}"
                    else -> "—"
                }
                Text(
                    text = movementText,
                    style = TextStyle(color = movementColor, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                )
            }
            Text(
                text = "Last: ${formatRank(snapshot.leagueLastRank)}",
                style = TextStyle(color = muted, fontSize = 7.sp)
            )
        }
    }
}

class RefreshAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: androidx.glance.action.ActionParameters
    ) {
        try {
            FplRepository(context).refresh()
        } catch (_: Throwable) {
            // Error is stored and shown after refresh.
        }
        FplWidget().update(context, glanceId)
    }
}

private fun loadBitmap(file: java.io.File): Bitmap? = try {
    if (!file.exists() || file.length() <= 150L) null else BitmapFactory.decodeFile(file.absolutePath)
} catch (_: Throwable) {
    null
}

private fun createKitBitmap(teamShort: String): Bitmap {
    val bitmap = Bitmap.createBitmap(72, 72, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    val (body, accent) = kitColours(teamShort)
    val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = body }
    val accentPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = accent }

    val shirt = Path().apply {
        moveTo(23f, 15f)
        lineTo(31f, 10f)
        lineTo(41f, 10f)
        lineTo(49f, 15f)
        lineTo(63f, 23f)
        lineTo(55f, 37f)
        lineTo(48f, 33f)
        lineTo(48f, 63f)
        lineTo(24f, 63f)
        lineTo(24f, 33f)
        lineTo(17f, 37f)
        lineTo(9f, 23f)
        close()
    }
    canvas.drawPath(shirt, paint)
    canvas.drawRect(24f, 20f, 48f, 25f, accentPaint)
    canvas.drawCircle(36f, 12f, 5f, accentPaint)
    return bitmap
}

private fun kitColours(teamShortRaw: String): Pair<Int, Int> {
    val team = teamShortRaw.uppercase(Locale.UK)
    return when (team) {
        "ARS" -> AndroidColor.rgb(219, 0, 7) to AndroidColor.WHITE
        "AVL" -> AndroidColor.rgb(103, 14, 54) to AndroidColor.rgb(149, 191, 229)
        "BOU" -> AndroidColor.rgb(218, 41, 28) to AndroidColor.rgb(20, 20, 20)
        "BRE" -> AndroidColor.rgb(228, 0, 43) to AndroidColor.WHITE
        "BHA" -> AndroidColor.rgb(0, 87, 184) to AndroidColor.WHITE
        "BUR" -> AndroidColor.rgb(108, 29, 69) to AndroidColor.rgb(153, 204, 255)
        "CHE" -> AndroidColor.rgb(3, 70, 148) to AndroidColor.WHITE
        "CRY" -> AndroidColor.rgb(27, 69, 143) to AndroidColor.rgb(196, 18, 48)
        "EVE" -> AndroidColor.rgb(0, 51, 153) to AndroidColor.WHITE
        "FUL" -> AndroidColor.WHITE to AndroidColor.rgb(20, 20, 20)
        "LEE" -> AndroidColor.WHITE to AndroidColor.rgb(255, 205, 0)
        "LIV" -> AndroidColor.rgb(200, 16, 46) to AndroidColor.WHITE
        "MCI" -> AndroidColor.rgb(108, 171, 221) to AndroidColor.WHITE
        "MUN" -> AndroidColor.rgb(218, 41, 28) to AndroidColor.rgb(255, 205, 0)
        "NEW" -> AndroidColor.rgb(30, 30, 30) to AndroidColor.WHITE
        "NFO" -> AndroidColor.rgb(221, 0, 0) to AndroidColor.WHITE
        "SUN" -> AndroidColor.rgb(235, 23, 40) to AndroidColor.WHITE
        "TOT" -> AndroidColor.WHITE to AndroidColor.rgb(19, 34, 87)
        "WHU" -> AndroidColor.rgb(122, 38, 58) to AndroidColor.rgb(27, 177, 231)
        "WOL" -> AndroidColor.rgb(253, 185, 19) to AndroidColor.rgb(35, 31, 32)
        else -> AndroidColor.rgb(45, 74, 255) to AndroidColor.WHITE
    }
}

private fun rankMovement(current: Int, previous: Int): Int {
    if (current <= 0 || previous <= 0) return 0
    return previous - current
}

private fun formatRank(value: Int): String =
    if (value <= 0) "-" else NumberFormat.getIntegerInstance(Locale.UK).format(value)

private fun formatTime(epoch: Long): String {
    if (epoch <= 0L) return "-"
    return SimpleDateFormat("HH:mm", Locale.UK).format(Date(epoch))
}

private fun compactTeamName(value: String): String {
    val upper = value.uppercase(Locale.UK)
    return if (upper.length <= 17) upper else upper.take(16) + "…"
}

private fun compactName(value: String): String =
    if (value.length <= 10) value else value.take(9) + "…"

private fun compactLeagueName(value: String): String {
    val clean = if (value.isBlank()) "Your League" else value
    return if (clean.length <= 17) clean else clean.take(16) + "…"
}

private fun ordinal(value: Int): String {
    if (value <= 0) return "-"
    val mod100 = value % 100
    val suffix = if (mod100 in 11..13) {
        "th"
    } else {
        when (value % 10) {
            1 -> "st"
            2 -> "nd"
            3 -> "rd"
            else -> "th"
        }
    }
    return "$value$suffix"
}

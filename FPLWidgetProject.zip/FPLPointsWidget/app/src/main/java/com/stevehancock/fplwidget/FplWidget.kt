package com.stevehancock.fplwidget

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.ImageProvider
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.appWidgetBackground
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FplWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val store = WidgetStore(context)
        provideContent {
            WidgetContent(store.teamId, store.load())
        }
    }
}

@Composable
private fun WidgetContent(teamId: Int?, snapshot: WidgetSnapshot?) {
    val white = ColorProvider(Color(0xFFF8FAFF))
    val green = ColorProvider(Color(0xFF00FF87))
    val red = ColorProvider(Color(0xFFFF5E77))
    val muted = ColorProvider(Color(0xFFB8C0E0))
    val muted2 = ColorProvider(Color(0xFF8E98C4))
    val card = ColorProvider(Color(0xAA121B59))
    val cardPurple = ColorProvider(Color(0xAA271B73))
    val line = ColorProvider(Color(0x554A65D6))

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(ImageProvider(R.drawable.widget_bg), ContentScale.FillBounds)
            .appWidgetBackground()
            .cornerRadius(24.dp)
            .padding(10.dp)
    ) {
        if (teamId == null) {
            EmptyState(
                title = "FPL WIDGET V2",
                message = "Tap the app and enter your FPL Team ID."
            )
            return@Column
        }

        if (snapshot == null) {
            EmptyState(
                title = "FPL WIDGET V2",
                message = "Tap refresh to load your live data."
            )
            Spacer(GlanceModifier.height(8.dp))
            Text(
                text = "↻  Refresh",
                modifier = GlanceModifier
                    .background(cardPurple)
                    .cornerRadius(16.dp)
                    .padding(8.dp)
                    .clickable(actionRunCallback<RefreshAction>()),
                style = TextStyle(color = green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            )
            return@Column
        }

        // Header
        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PL",
                modifier = GlanceModifier
                    .background(ColorProvider(Color(0x332D4AFF)))
                    .cornerRadius(12.dp)
                    .padding(6.dp),
                style = TextStyle(color = white, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(GlanceModifier.width(7.dp))
            Text(
                text = "GW${snapshot.gameweek} -",
                style = TextStyle(color = green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(GlanceModifier.width(5.dp))
            Text(
                text = compactTeamName(snapshot.teamName),
                modifier = GlanceModifier.defaultWeight(),
                style = TextStyle(color = white, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            )
            Text(
                text = "${snapshot.playersDone} done  •  ${snapshot.playersRemaining} left",
                style = TextStyle(color = muted, fontSize = 10.sp)
            )
            Spacer(GlanceModifier.width(7.dp))
            Text(
                text = "↻",
                modifier = GlanceModifier
                    .background(ColorProvider(Color(0x442B3D85)))
                    .cornerRadius(18.dp)
                    .padding(8.dp)
                    .clickable(actionRunCallback<RefreshAction>()),
                style = TextStyle(color = white, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            )
        }

        Spacer(GlanceModifier.height(7.dp))

        // Three-column dashboard body.
        Row(modifier = GlanceModifier.fillMaxWidth()) {
            LeftScoreColumn(snapshot, white, green, red, muted, card, line)
            Spacer(GlanceModifier.width(7.dp))
            RemainingColumn(snapshot, white, muted, muted2, card, line, GlanceModifier.defaultWeight())
            Spacer(GlanceModifier.width(7.dp))
            RankColumn(snapshot, white, green, red, muted, cardPurple)
        }
    }
}

@Composable
private fun EmptyState(title: String, message: String) {
    val white = ColorProvider(Color.White)
    val green = ColorProvider(Color(0xFF00FF87))
    val muted = ColorProvider(Color(0xFFB8C0E0))
    Text(
        text = title,
        style = TextStyle(color = green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    )
    Spacer(GlanceModifier.height(7.dp))
    Text(
        text = message,
        style = TextStyle(color = white, fontSize = 18.sp, fontWeight = FontWeight.Bold)
    )
    Spacer(GlanceModifier.height(5.dp))
    Text(
        text = "Open FPL Points Widget to configure it.",
        style = TextStyle(color = muted, fontSize = 11.sp)
    )
}

@Composable
private fun LeftScoreColumn(
    snapshot: WidgetSnapshot,
    white: ColorProvider,
    green: ColorProvider,
    red: ColorProvider,
    muted: ColorProvider,
    card: ColorProvider,
    line: ColorProvider
) {
    Column(modifier = GlanceModifier.width(118.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = GlanceModifier.width(75.dp)) {
                Text(
                    text = snapshot.livePoints.toString(),
                    style = TextStyle(color = white, fontSize = 50.sp, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "LIVE POINTS",
                    style = TextStyle(color = white, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                )
            }
            Spacer(
                modifier = GlanceModifier
                    .width(1.dp)
                    .height(62.dp)
                    .background(line)
            )
            Spacer(GlanceModifier.width(7.dp))
            Column {
                Text(
                    text = "Avg ${snapshot.averagePoints}",
                    style = TextStyle(color = white, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                )
                Spacer(GlanceModifier.height(5.dp))
                val diff = snapshot.livePoints - snapshot.averagePoints
                val diffColor = if (diff >= 0) green else red
                val diffPrefix = if (diff >= 0) "▲ +" else "▼ "
                Text(
                    text = "$diffPrefix$diff",
                    modifier = GlanceModifier
                        .background(ColorProvider(if (diff >= 0) Color(0x3324FF9D) else Color(0x33FF5E77)))
                        .cornerRadius(14.dp)
                        .padding(5.dp),
                    style = TextStyle(color = diffColor, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                )
                Spacer(GlanceModifier.height(3.dp))
                Text(
                    text = "vs avg",
                    style = TextStyle(color = muted, fontSize = 9.sp)
                )
            }
        }

        Spacer(GlanceModifier.height(3.dp))
        Text(
            text = "Updated ${formatTime(snapshot.updatedAt)} - live estimate",
            style = TextStyle(color = muted, fontSize = 8.sp)
        )
        Spacer(GlanceModifier.height(6.dp))

        Column(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(card)
                .cornerRadius(12.dp)
                .padding(7.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "C",
                    modifier = GlanceModifier
                        .background(ColorProvider(Color(0xFFE93956)))
                        .cornerRadius(11.dp)
                        .padding(5.dp),
                    style = TextStyle(color = white, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                )
                Spacer(GlanceModifier.width(7.dp))
                Column {
                    val capSuffix = if (snapshot.captainMultiplier >= 3) " (TC)" else " (C)"
                    Text(
                        text = "Captain: ${compactName(snapshot.captainName)}$capSuffix",
                        style = TextStyle(color = white, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${snapshot.captainPoints} pts",
                        style = TextStyle(color = muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    )
                }
            }
        }
    }
}

@Composable
private fun RemainingColumn(
    snapshot: WidgetSnapshot,
    white: ColorProvider,
    muted: ColorProvider,
    muted2: ColorProvider,
    card: ColorProvider,
    line: ColorProvider,
    modifier: GlanceModifier
) {
    Column(
        modifier = modifier
            .background(card)
            .cornerRadius(13.dp)
            .padding(8.dp)
    ) {
        Row(modifier = GlanceModifier.fillMaxWidth()) {
            Text(
                text = "Remaining",
                modifier = GlanceModifier.defaultWeight(),
                style = TextStyle(color = muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            )
            Text(
                text = "›",
                style = TextStyle(color = muted, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            )
        }
        Spacer(GlanceModifier.height(4.dp))

        val rows = snapshot.remainingFixtures.take(3)
        if (rows.isEmpty()) {
            Text(
                text = if (snapshot.playersRemaining == 0) "All players finished" else "Fixtures loading...",
                style = TextStyle(color = muted2, fontSize = 9.sp)
            )
        } else {
            rows.forEachIndexed { index, fixture ->
                FixtureRow(fixture, white, muted)
                if (index < rows.lastIndex) {
                    Spacer(
                        modifier = GlanceModifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(line)
                    )
                }
            }
            if (snapshot.remainingFixtures.size > 3) {
                Spacer(GlanceModifier.height(3.dp))
                Text(
                    text = "+${snapshot.remainingFixtures.size - 3} more fixture${if (snapshot.remainingFixtures.size - 3 == 1) "" else "s"}",
                    style = TextStyle(color = muted2, fontSize = 8.sp)
                )
            }
        }
    }
}

@Composable
private fun FixtureRow(
    fixture: RemainingFixture,
    white: ColorProvider,
    muted: ColorProvider
) {
    Row(
        modifier = GlanceModifier.fillMaxWidth().padding(4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = fixture.label,
            modifier = GlanceModifier.defaultWeight(),
            style = TextStyle(color = muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        )
        Text(
            text = fixture.count.toString(),
            style = TextStyle(color = white, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        )
    }
}

@Composable
private fun RankColumn(
    snapshot: WidgetSnapshot,
    white: ColorProvider,
    green: ColorProvider,
    red: ColorProvider,
    muted: ColorProvider,
    cardPurple: ColorProvider
) {
    Column(modifier = GlanceModifier.width(132.dp)) {
        Column(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(cardPurple)
                .cornerRadius(13.dp)
                .padding(8.dp)
        ) {
            Text(
                text = "Overall Rank  ▥",
                style = TextStyle(color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(GlanceModifier.height(3.dp))
            Text(
                text = formatRank(snapshot.overallRank),
                style = TextStyle(color = white, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            )
            val movement = rankMovement(snapshot.overallRank, snapshot.previousOverallRank)
            val movementColor = when {
                movement > 0 -> green
                movement < 0 -> red
                else -> muted
            }
            val movementText = when {
                movement > 0 -> "▲ ${formatRank(movement)}"
                movement < 0 -> "▼ ${formatRank(-movement)}"
                else -> "—"
            }
            Text(
                text = movementText,
                style = TextStyle(color = movementColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Last rank: ${formatRank(snapshot.previousOverallRank)}",
                style = TextStyle(color = muted, fontSize = 8.sp)
            )
        }

        Spacer(GlanceModifier.height(6.dp))

        Column(
            modifier = GlanceModifier
                .fillMaxWidth()
                .background(cardPurple)
                .cornerRadius(13.dp)
                .padding(8.dp)
        ) {
            Text(
                text = "${compactLeagueName(snapshot.leagueName)}  ♟",
                style = TextStyle(color = muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(GlanceModifier.height(3.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = ordinal(snapshot.leagueRank),
                    modifier = GlanceModifier.defaultWeight(),
                    style = TextStyle(color = white, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                )
                val movement = rankMovement(snapshot.leagueRank, snapshot.leagueLastRank)
                val movementColor = when {
                    movement > 0 -> green
                    movement < 0 -> red
                    else -> muted
                }
                val movementText = when {
                    movement > 0 -> "▲${movement}"
                    movement < 0 -> "▼${-movement}"
                    else -> "—"
                }
                Text(
                    text = movementText,
                    style = TextStyle(color = movementColor, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                )
            }
            Text(
                text = "Last rank: ${formatRank(snapshot.leagueLastRank)}",
                style = TextStyle(color = muted, fontSize = 8.sp)
            )
        }
    }
}

class RefreshAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: androidx.glance.action.ActionParameters
    ) {
        try {
            FplRepository(context).refresh()
        } catch (_: Throwable) {
            // Error is stored and shown after refresh.
        }
        FplWidget().update(context, glanceId)
    }
}

private fun rankMovement(current: Int, previous: Int): Int {
    if (current <= 0 || previous <= 0) return 0
    return previous - current
}

private fun formatRank(value: Int): String =
    if (value <= 0) "-" else NumberFormat.getIntegerInstance(Locale.UK).format(value)

private fun formatTime(epoch: Long): String {
    if (epoch <= 0L) return "-"
    return SimpleDateFormat("HH:mm", Locale.UK).format(Date(epoch))
}

private fun compactTeamName(value: String): String {
    val upper = value.uppercase(Locale.UK)
    return if (upper.length <= 20) upper else upper.take(19) + "…"
}

private fun compactName(value: String): String =
    if (value.length <= 11) value else value.take(10) + "…"

private fun compactLeagueName(value: String): String {
    val clean = if (value.isBlank()) "Your League" else value
    return if (clean.length <= 18) clean else clean.take(17) + "…"
}

private fun ordinal(value: Int): String {
    if (value <= 0) return "-"
    val mod100 = value % 100
    val suffix = if (mod100 in 11..13) {
        "th"
    } else {
        when (value % 10) {
            1 -> "st"
            2 -> "nd"
            3 -> "rd"
            else -> "th"
        }
    }
    return "$value$suffix"
}

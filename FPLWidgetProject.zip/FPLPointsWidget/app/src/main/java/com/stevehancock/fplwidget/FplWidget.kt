package com.stevehancock.fplwidget

import android.content.Context
import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.appWidgetBackground
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.appwidget.action.ActionCallback
import androidx.glance.appwidget.action.actionRunCallback
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Column
import androidx.glance.layout.Row
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.defaultWeight
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.layout.width
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FplWidget : GlanceAppWidget() {
    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val store = WidgetStore(context)
        val teamId = store.teamId
        val snapshot = store.load()

        provideContent {
            WidgetContent(context, teamId, snapshot)
        }
    }
}

@Composable
private fun WidgetContent(context: Context, teamId: Int?, snapshot: WidgetSnapshot?) {
    val bg = ColorProvider(Color(0xFF171326))
    val green = ColorProvider(Color(0xFF00FF87))
    val white = ColorProvider(Color.White)
    val muted = ColorProvider(Color(0xFFB9B3C9))

    Column(
        modifier = GlanceModifier
            .fillMaxSize()
            .background(bg)
            .appWidgetBackground()
            .cornerRadius(22.dp)
            .padding(16.dp)
            .clickable(actionStartActivity(Intent(context, MainActivity::class.java))),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (teamId == null) {
            Text(
                text = "FPL POINTS",
                style = TextStyle(color = green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(GlanceModifier.height(8.dp))
            Text(
                text = "Tap to add your Team ID",
                style = TextStyle(color = white, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(GlanceModifier.height(6.dp))
            Text(
                text = "Then add this widget to your home screen.",
                style = TextStyle(color = muted, fontSize = 12.sp)
            )
            return@Column
        }

        if (snapshot == null) {
            Text(
                text = "FPL POINTS",
                style = TextStyle(color = green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(GlanceModifier.height(8.dp))
            Text(
                text = "Tap refresh to load your team",
                style = TextStyle(color = white, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            )
            Spacer(GlanceModifier.height(10.dp))
            Text(
                text = "↻ Refresh",
                modifier = GlanceModifier.clickable(actionRunCallback<RefreshAction>()),
                style = TextStyle(color = green, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            )
            return@Column
        }

        Row(
            modifier = GlanceModifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = GlanceModifier.defaultWeight()) {
                Text(
                    text = "GW${snapshot.gameweek}  •  ${snapshot.teamName}",
                    style = TextStyle(color = green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                )
                Spacer(GlanceModifier.height(3.dp))
                Text(
                    text = "${snapshot.livePoints}",
                    style = TextStyle(color = white, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "LIVE POINTS",
                    style = TextStyle(color = muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                )
            }

            Spacer(GlanceModifier.width(14.dp))

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "Overall ${formatRank(snapshot.overallRank)}",
                    style = TextStyle(color = white, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                )
                Spacer(GlanceModifier.height(4.dp))
                Text(
                    text = "GW ${formatRank(snapshot.gameweekRank)}",
                    style = TextStyle(color = white, fontSize = 12.sp)
                )
                Spacer(GlanceModifier.height(7.dp))
                Text(
                    text = "${snapshot.playersDone} done  •  ${snapshot.playersRemaining} left",
                    style = TextStyle(color = muted, fontSize = 11.sp)
                )
                Spacer(GlanceModifier.height(8.dp))
                Text(
                    text = "↻ Refresh",
                    modifier = GlanceModifier.clickable(actionRunCallback<RefreshAction>()),
                    style = TextStyle(color = green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                )
            }
        }

        Spacer(GlanceModifier.height(8.dp))
        val footer = if (snapshot.error.isNullOrBlank()) {
            "Updated ${formatTime(snapshot.updatedAt)} • live estimate"
        } else {
            "${snapshot.error} • tap refresh"
        }
        Text(
            text = footer,
            style = TextStyle(color = muted, fontSize = 9.sp)
        )
    }
}

class RefreshAction : ActionCallback {
    override suspend fun onAction(
        context: Context,
        glanceId: GlanceId,
        parameters: androidx.glance.action.ActionParameters
    ) {
        try {
            FplRepository(context).refresh()
        } catch (_: Throwable) {
            // Error is stored and displayed in the widget.
        }
        FplWidget().update(context, glanceId)
    }
}

private fun formatRank(value: Int): String =
    if (value <= 0) "-" else NumberFormat.getIntegerInstance(Locale.UK).format(value)

private fun formatTime(epoch: Long): String {
    if (epoch <= 0L) return "-"
    return SimpleDateFormat("HH:mm", Locale.UK).format(Date(epoch))
}

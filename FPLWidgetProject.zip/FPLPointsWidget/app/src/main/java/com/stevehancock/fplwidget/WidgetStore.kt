package com.stevehancock.fplwidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class FixtureCard(
    val teamId: Int,
    val teamCode: Int,
    val teamShort: String,
    val opponentShort: String,
    val homeAway: String,
    val count: Int,
    val points: Int,
    val kickoffAt: Long,
    val finished: Boolean
)

data class LeagueStanding(
    val entryId: Int,
    val rank: Int,
    val lastRank: Int,
    val teamName: String,
    val eventPoints: Int,
    val totalPoints: Int,
    val isUser: Boolean
)

data class WidgetSnapshot(
    val teamName: String,
    val gameweek: Int,
    val livePoints: Int,
    val averagePoints: Int,
    val overallRank: Int,
    val previousOverallRank: Int,
    val gameweekRank: Int,
    val playersDone: Int,
    val playersRemaining: Int,
    val captainName: String,
    val captainPoints: Int,
    val captainMultiplier: Int,
    val captainTeamId: Int,
    val captainTeamCode: Int,
    val captainTeamShort: String,
    val leagueId: Int,
    val leagueName: String,
    val leagueRank: Int,
    val leagueLastRank: Int,
    val leagueUsesLiveScores: Boolean,
    val fixtures: List<FixtureCard>,
    val leagueStandings: List<LeagueStanding>,
    val updatedAt: Long,
    val error: String? = null
)

class WidgetStore(context: Context) {
    private val prefs = context.getSharedPreferences("fpl_widget", Context.MODE_PRIVATE)

    var teamId: Int?
        get() = prefs.getInt("team_id", -1).takeIf { it > 0 }
        set(value) {
            prefs.edit().putInt("team_id", value ?: -1).apply()
        }

    var leagueId: Int?
        get() = prefs.getInt("league_id", -1).takeIf { it > 0 }
        set(value) {
            prefs.edit().putInt("league_id", value ?: -1).apply()
        }

    var fixturePage: Int
        get() = prefs.getInt("fixture_page", 0).coerceAtLeast(0)
        set(value) {
            prefs.edit().putInt("fixture_page", value.coerceAtLeast(0)).apply()
        }

    fun save(snapshot: WidgetSnapshot) {
        val fixturesJson = JSONArray()
        snapshot.fixtures.forEach { fixture ->
            fixturesJson.put(
                JSONObject()
                    .put("team_id", fixture.teamId)
                    .put("team_code", fixture.teamCode)
                    .put("team_short", fixture.teamShort)
                    .put("opponent_short", fixture.opponentShort)
                    .put("home_away", fixture.homeAway)
                    .put("count", fixture.count)
                    .put("points", fixture.points)
                    .put("kickoff_at", fixture.kickoffAt)
                    .put("finished", fixture.finished)
            )
        }

        val leagueJson = JSONArray()
        snapshot.leagueStandings.forEach { standing ->
            leagueJson.put(
                JSONObject()
                    .put("entry_id", standing.entryId)
                    .put("rank", standing.rank)
                    .put("last_rank", standing.lastRank)
                    .put("team_name", standing.teamName)
                    .put("event_points", standing.eventPoints)
                    .put("total_points", standing.totalPoints)
                    .put("is_user", standing.isUser)
            )
        }

        prefs.edit()
            .putString("team_name", snapshot.teamName)
            .putInt("gameweek", snapshot.gameweek)
            .putInt("live_points", snapshot.livePoints)
            .putInt("average_points", snapshot.averagePoints)
            .putInt("overall_rank", snapshot.overallRank)
            .putInt("previous_overall_rank", snapshot.previousOverallRank)
            .putInt("gameweek_rank", snapshot.gameweekRank)
            .putInt("players_done", snapshot.playersDone)
            .putInt("players_remaining", snapshot.playersRemaining)
            .putString("captain_name", snapshot.captainName)
            .putInt("captain_points", snapshot.captainPoints)
            .putInt("captain_multiplier", snapshot.captainMultiplier)
            .putInt("captain_team_id", snapshot.captainTeamId)
            .putInt("captain_team_code", snapshot.captainTeamCode)
            .putString("captain_team_short", snapshot.captainTeamShort)
            .putInt("snapshot_league_id", snapshot.leagueId)
            .putString("league_name", snapshot.leagueName)
            .putInt("league_rank", snapshot.leagueRank)
            .putInt("league_last_rank", snapshot.leagueLastRank)
            .putBoolean("league_uses_live_scores", snapshot.leagueUsesLiveScores)
            .putString("fixture_cards", fixturesJson.toString())
            .putString("league_standings", leagueJson.toString())
            .putLong("updated_at", snapshot.updatedAt)
            .putString("error", snapshot.error)
            .apply()
    }

    fun saveError(message: String) {
        prefs.edit()
            .putString("error", message)
            .putLong("updated_at", System.currentTimeMillis())
            .apply()
    }

    fun load(): WidgetSnapshot? {
        val name = prefs.getString("team_name", null) ?: return null
        val fixtures = readFixtures()
        val standings = readLeagueStandings()

        return WidgetSnapshot(
            teamName = name,
            gameweek = prefs.getInt("gameweek", 0),
            livePoints = prefs.getInt("live_points", 0),
            averagePoints = prefs.getInt("average_points", 0),
            overallRank = prefs.getInt("overall_rank", 0),
            previousOverallRank = prefs.getInt("previous_overall_rank", 0),
            gameweekRank = prefs.getInt("gameweek_rank", 0),
            playersDone = prefs.getInt("players_done", 0),
            playersRemaining = prefs.getInt("players_remaining", 0),
            captainName = prefs.getString("captain_name", "Captain") ?: "Captain",
            captainPoints = prefs.getInt("captain_points", 0),
            captainMultiplier = prefs.getInt("captain_multiplier", 2),
            captainTeamId = prefs.getInt("captain_team_id", 0),
            captainTeamCode = prefs.getInt("captain_team_code", 0),
            captainTeamShort = prefs.getString("captain_team_short", "") ?: "",
            leagueId = prefs.getInt("snapshot_league_id", 0),
            leagueName = prefs.getString("league_name", "Your League") ?: "Your League",
            leagueRank = prefs.getInt("league_rank", 0),
            leagueLastRank = prefs.getInt("league_last_rank", 0),
            leagueUsesLiveScores = prefs.getBoolean("league_uses_live_scores", false),
            fixtures = fixtures,
            leagueStandings = standings,
            updatedAt = prefs.getLong("updated_at", 0L),
            error = prefs.getString("error", null)
        )
    }

    private fun readFixtures(): List<FixtureCard> {
        val result = mutableListOf<FixtureCard>()
        val raw = prefs.getString("fixture_cards", null)
        if (!raw.isNullOrBlank()) {
            try {
                val array = JSONArray(raw)
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    result += FixtureCard(
                        teamId = item.optInt("team_id", 0),
                        teamCode = item.optInt("team_code", 0),
                        teamShort = item.optString("team_short", "TEAM"),
                        opponentShort = item.optString("opponent_short", "OPP"),
                        homeAway = item.optString("home_away", ""),
                        count = item.optInt("count", 0),
                        points = item.optInt("points", 0),
                        kickoffAt = item.optLong("kickoff_at", 0L),
                        finished = item.optBoolean("finished", false)
                    )
                }
                return result
            } catch (_: Throwable) {
                result.clear()
            }
        }

        // Backwards compatibility with the V2.2 fixture cache. It deliberately omits
        // fake dates/times; the next refresh replaces these rows with real fixture data.
        val legacy = prefs.getString("remaining_fixtures", "[]") ?: "[]"
        try {
            val array = JSONArray(legacy)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                result += FixtureCard(
                    teamId = 0,
                    teamCode = item.optInt("home_code", 0),
                    teamShort = item.optString("home_short", "TEAM"),
                    opponentShort = item.optString("away_short", "OPP"),
                    homeAway = "",
                    count = item.optInt("count", 0),
                    points = 0,
                    kickoffAt = 0L,
                    finished = false
                )
            }
        } catch (_: Throwable) {
            // Leave empty until the next refresh.
        }
        return result
    }

    private fun readLeagueStandings(): List<LeagueStanding> {
        val result = mutableListOf<LeagueStanding>()
        val raw = prefs.getString("league_standings", "[]") ?: "[]"
        try {
            val array = JSONArray(raw)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                result += LeagueStanding(
                    entryId = item.optInt("entry_id", 0),
                    rank = item.optInt("rank", 0),
                    lastRank = item.optInt("last_rank", 0),
                    teamName = item.optString("team_name", "Team"),
                    eventPoints = item.optInt("event_points", 0),
                    totalPoints = item.optInt("total_points", 0),
                    isUser = item.optBoolean("is_user", false)
                )
            }
        } catch (_: Throwable) {
            // Keep the widget usable after an upgrade from an older snapshot.
        }
        return result
    }
}

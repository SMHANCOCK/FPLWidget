package com.stevehancock.fplwidget

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class RemainingFixture(
    val label: String,
    val count: Int
)

data class WidgetSnapshot(
    val teamName: String,
    val gameweek: Int,
    val livePoints: Int,
    val averagePoints: Int,
    val overallRank: Int,
    val previousOverallRank: Int,
    val gameweekRank: Int,
    val playersDone: Int,
    val playersRemaining: Int,
    val captainName: String,
    val captainPoints: Int,
    val captainMultiplier: Int,
    val leagueId: Int,
    val leagueName: String,
    val leagueRank: Int,
    val leagueLastRank: Int,
    val remainingFixtures: List<RemainingFixture>,
    val updatedAt: Long,
    val error: String? = null
)

class WidgetStore(context: Context) {
    private val prefs = context.getSharedPreferences("fpl_widget", Context.MODE_PRIVATE)

    var teamId: Int?
        get() = prefs.getInt("team_id", -1).takeIf { it > 0 }
        set(value) {
            prefs.edit().putInt("team_id", value ?: -1).apply()
        }

    var leagueId: Int?
        get() = prefs.getInt("league_id", -1).takeIf { it > 0 }
        set(value) {
            prefs.edit().putInt("league_id", value ?: -1).apply()
        }

    fun save(snapshot: WidgetSnapshot) {
        val fixturesJson = JSONArray()
        snapshot.remainingFixtures.forEach { fixture ->
            fixturesJson.put(
                JSONObject()
                    .put("label", fixture.label)
                    .put("count", fixture.count)
            )
        }

        prefs.edit()
            .putString("team_name", snapshot.teamName)
            .putInt("gameweek", snapshot.gameweek)
            .putInt("live_points", snapshot.livePoints)
            .putInt("average_points", snapshot.averagePoints)
            .putInt("overall_rank", snapshot.overallRank)
            .putInt("previous_overall_rank", snapshot.previousOverallRank)
            .putInt("gameweek_rank", snapshot.gameweekRank)
            .putInt("players_done", snapshot.playersDone)
            .putInt("players_remaining", snapshot.playersRemaining)
            .putString("captain_name", snapshot.captainName)
            .putInt("captain_points", snapshot.captainPoints)
            .putInt("captain_multiplier", snapshot.captainMultiplier)
            .putInt("snapshot_league_id", snapshot.leagueId)
            .putString("league_name", snapshot.leagueName)
            .putInt("league_rank", snapshot.leagueRank)
            .putInt("league_last_rank", snapshot.leagueLastRank)
            .putString("remaining_fixtures", fixturesJson.toString())
            .putLong("updated_at", snapshot.updatedAt)
            .putString("error", snapshot.error)
            .apply()
    }

    fun saveError(message: String) {
        prefs.edit()
            .putString("error", message)
            .putLong("updated_at", System.currentTimeMillis())
            .apply()
    }

    fun load(): WidgetSnapshot? {
        val name = prefs.getString("team_name", null) ?: return null
        val fixtures = mutableListOf<RemainingFixture>()
        val rawFixtures = prefs.getString("remaining_fixtures", "[]") ?: "[]"
        try {
            val array = JSONArray(rawFixtures)
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                fixtures += RemainingFixture(
                    label = item.optString("label", "Fixture"),
                    count = item.optInt("count", 0)
                )
            }
        } catch (_: Throwable) {
            // Keep the widget usable if old V1 preferences are present.
        }

        return WidgetSnapshot(
            teamName = name,
            gameweek = prefs.getInt("gameweek", 0),
            livePoints = prefs.getInt("live_points", 0),
            averagePoints = prefs.getInt("average_points", 0),
            overallRank = prefs.getInt("overall_rank", 0),
            previousOverallRank = prefs.getInt("previous_overall_rank", 0),
            gameweekRank = prefs.getInt("gameweek_rank", 0),
            playersDone = prefs.getInt("players_done", 0),
            playersRemaining = prefs.getInt("players_remaining", 0),
            captainName = prefs.getString("captain_name", "Captain") ?: "Captain",
            captainPoints = prefs.getInt("captain_points", 0),
            captainMultiplier = prefs.getInt("captain_multiplier", 2),
            leagueId = prefs.getInt("snapshot_league_id", 0),
            leagueName = prefs.getString("league_name", "Your League") ?: "Your League",
            leagueRank = prefs.getInt("league_rank", 0),
            leagueLastRank = prefs.getInt("league_last_rank", 0),
            remainingFixtures = fixtures,
            updatedAt = prefs.getLong("updated_at", 0L),
            error = prefs.getString("error", null)
        )
    }
}

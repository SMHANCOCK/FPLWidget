package com.stevehancock.fplwidget

import android.content.Context

data class WidgetSnapshot(
    val teamName: String,
    val gameweek: Int,
    val livePoints: Int,
    val overallRank: Int,
    val gameweekRank: Int,
    val playersDone: Int,
    val playersRemaining: Int,
    val updatedAt: Long,
    val error: String? = null
)

class WidgetStore(context: Context) {
    private val prefs = context.getSharedPreferences("fpl_widget", Context.MODE_PRIVATE)

    var teamId: Int?
        get() = prefs.getInt("team_id", -1).takeIf { it > 0 }
        set(value) {
            prefs.edit().putInt("team_id", value ?: -1).apply()
        }

    fun save(snapshot: WidgetSnapshot) {
        prefs.edit()
            .putString("team_name", snapshot.teamName)
            .putInt("gameweek", snapshot.gameweek)
            .putInt("live_points", snapshot.livePoints)
            .putInt("overall_rank", snapshot.overallRank)
            .putInt("gameweek_rank", snapshot.gameweekRank)
            .putInt("players_done", snapshot.playersDone)
            .putInt("players_remaining", snapshot.playersRemaining)
            .putLong("updated_at", snapshot.updatedAt)
            .putString("error", snapshot.error)
            .apply()
    }

    fun saveError(message: String) {
        prefs.edit()
            .putString("error", message)
            .putLong("updated_at", System.currentTimeMillis())
            .apply()
    }

    fun load(): WidgetSnapshot? {
        val name = prefs.getString("team_name", null) ?: return null
        return WidgetSnapshot(
            teamName = name,
            gameweek = prefs.getInt("gameweek", 0),
            livePoints = prefs.getInt("live_points", 0),
            overallRank = prefs.getInt("overall_rank", 0),
            gameweekRank = prefs.getInt("gameweek_rank", 0),
            playersDone = prefs.getInt("players_done", 0),
            playersRemaining = prefs.getInt("players_remaining", 0),
            updatedAt = prefs.getLong("updated_at", 0L),
            error = prefs.getString("error", null)
        )
    }
}

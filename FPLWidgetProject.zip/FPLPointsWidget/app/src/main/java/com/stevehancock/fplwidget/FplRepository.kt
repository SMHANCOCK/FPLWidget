package com.stevehancock.fplwidget

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class LeagueChoice(
    val id: Int,
    val name: String,
    val rank: Int,
    val lastRank: Int
)

private data class TeamMeta(
    val id: Int,
    val code: Int,
    val shortName: String
)

private data class FixtureInfo(
    val homeTeam: Int,
    val awayTeam: Int,
    val kickoff: String,
    val finished: Boolean
)

class FplRepository(private val context: Context) {
    private val base = "https://fantasy.premierleague.com/api"

    suspend fun refresh(): WidgetSnapshot = withContext(Dispatchers.IO) {
        val store = WidgetStore(context)
        val teamId = store.teamId ?: error("Enter your FPL Team ID first")

        try {
            val bootstrap = getJson("$base/bootstrap-static/")
            val gameweek = currentGameweek(bootstrap)
            val entry = getJson("$base/entry/$teamId/")
            val picks = getJson("$base/entry/$teamId/event/$gameweek/picks/")
            val live = getJson("$base/event/$gameweek/live/")
            val fixtures = getArray("$base/fixtures/?event=$gameweek")
            val history = getJson("$base/entry/$teamId/history/")

            val teamsById = HashMap<Int, TeamMeta>()
            val teams = bootstrap.getJSONArray("teams")
            for (i in 0 until teams.length()) {
                val team = teams.getJSONObject(i)
                val id = team.getInt("id")
                teamsById[id] = TeamMeta(
                    id = id,
                    code = team.optInt("code", id),
                    shortName = team.optString("short_name", "T$id")
                )
            }

            val playerTeam = HashMap<Int, Int>()
            val playerName = HashMap<Int, String>()
            val elements = bootstrap.getJSONArray("elements")
            for (i in 0 until elements.length()) {
                val player = elements.getJSONObject(i)
                val id = player.getInt("id")
                playerTeam[id] = player.getInt("team")
                playerName[id] = player.optString("web_name", "Player")
            }

            val livePoints = HashMap<Int, Int>()
            val liveElements = live.getJSONArray("elements")
            for (i in 0 until liveElements.length()) {
                val item = liveElements.getJSONObject(i)
                livePoints[item.getInt("id")] = item.getJSONObject("stats").optInt("total_points", 0)
            }

            val fixtureList = mutableListOf<FixtureInfo>()
            val teamFixtures = HashMap<Int, MutableList<FixtureInfo>>()
            for (i in 0 until fixtures.length()) {
                val fixture = fixtures.getJSONObject(i)
                val info = FixtureInfo(
                    homeTeam = fixture.getInt("team_h"),
                    awayTeam = fixture.getInt("team_a"),
                    kickoff = fixture.optString("kickoff_time", ""),
                    finished = fixture.optBoolean("finished", false) || fixture.optBoolean("finished_provisional", false)
                )
                fixtureList += info
                teamFixtures.getOrPut(info.homeTeam) { mutableListOf() }.add(info)
                teamFixtures.getOrPut(info.awayTeam) { mutableListOf() }.add(info)
            }

            var calculatedPoints = 0
            var scoringPlayers = 0
            var donePlayers = 0
            var captainName = "Captain"
            var captainPoints = 0
            var captainMultiplier = 2
            var captainTeamId = 0
            var captainTeamCode = 0
            var captainTeamShort = ""
            val scoringTeamIds = mutableListOf<Int>()

            val picksArray = picks.getJSONArray("picks")
            for (i in 0 until picksArray.length()) {
                val pick = picksArray.getJSONObject(i)
                val elementId = pick.getInt("element")
                val multiplier = pick.optInt("multiplier", 0)

                if (pick.optBoolean("is_captain", false)) {
                    captainName = playerName[elementId] ?: "Captain"
                    captainMultiplier = multiplier.coerceAtLeast(1)
                    captainPoints = (livePoints[elementId] ?: 0) * captainMultiplier
                    captainTeamId = playerTeam[elementId] ?: 0
                    val captainTeam = teamsById[captainTeamId]
                    captainTeamCode = captainTeam?.code ?: 0
                    captainTeamShort = captainTeam?.shortName ?: ""
                }

                if (multiplier <= 0) continue

                scoringPlayers++
                calculatedPoints += (livePoints[elementId] ?: 0) * multiplier

                val teamIdForPlayer = playerTeam[elementId]
                if (teamIdForPlayer != null) {
                    scoringTeamIds += teamIdForPlayer
                    val status = teamFixtures[teamIdForPlayer].orEmpty()
                    if (status.isNotEmpty() && status.all { it.finished }) {
                        donePlayers++
                    }
                }
            }

            val entryHistory = picks.optJSONObject("entry_history") ?: JSONObject()
            val transferCost = entryHistory.optInt("event_transfers_cost", 0)
            calculatedPoints -= transferCost

            val event = findEvent(bootstrap, gameweek)
            val averagePoints = event?.optInt("average_entry_score", 0) ?: 0

            val currentHistory = history.optJSONArray("current") ?: JSONArray()
            var previousOverallRank = 0
            for (i in currentHistory.length() - 1 downTo 0) {
                val row = currentHistory.getJSONObject(i)
                if (row.optInt("event", 0) < gameweek) {
                    previousOverallRank = row.optInt("overall_rank", 0)
                    break
                }
            }
            if (previousOverallRank <= 0) {
                previousOverallRank = entry.optInt("summary_overall_rank", 0)
            }

            val privateLeagues = readPrivateClassicLeagues(entry)
            val selectedLeague = selectLeague(privateLeagues, store.leagueId)
            if (store.leagueId == null && selectedLeague != null) {
                store.leagueId = selectedLeague.id
            }

            val remaining = buildRemainingFixtures(
                fixtureList = fixtureList,
                scoringTeamIds = scoringTeamIds,
                teamsById = teamsById
            )

            // Cache the small club images used by the widget. The UI has text/colour fallbacks,
            // so a failed image request never blocks live FPL data.
            val assets = AssetCache(context)
            remaining.flatMap { listOf(it.homeCode, it.awayCode) }
                .filter { it > 0 }
                .distinct()
                .forEach { assets.ensureBadge(it) }
            if (captainTeamCode > 0) {
                assets.ensureBadge(captainTeamCode)
                assets.ensureShirt(captainTeamCode, captainTeamId)
            }

            val snapshot = WidgetSnapshot(
                teamName = entry.optString("name", "My FPL Team"),
                gameweek = gameweek,
                livePoints = calculatedPoints,
                averagePoints = averagePoints,
                overallRank = entry.optInt("summary_overall_rank", entryHistory.optInt("overall_rank", 0)),
                previousOverallRank = previousOverallRank,
                gameweekRank = entryHistory.optInt("rank", entry.optInt("summary_event_rank", 0)),
                playersDone = donePlayers,
                playersRemaining = (scoringPlayers - donePlayers).coerceAtLeast(0),
                captainName = captainName,
                captainPoints = captainPoints,
                captainMultiplier = captainMultiplier,
                captainTeamId = captainTeamId,
                captainTeamCode = captainTeamCode,
                captainTeamShort = captainTeamShort,
                leagueId = selectedLeague?.id ?: 0,
                leagueName = selectedLeague?.name ?: "Your League",
                leagueRank = selectedLeague?.rank ?: 0,
                leagueLastRank = selectedLeague?.lastRank ?: 0,
                remainingFixtures = remaining,
                updatedAt = System.currentTimeMillis(),
                error = null
            )
            store.save(snapshot)
            snapshot
        } catch (t: Throwable) {
            val message = when {
                t.message?.contains("404") == true -> "Team ID not found"
                t.message?.contains("429") == true -> "FPL is rate limiting updates"
                else -> t.message?.take(90) ?: "Could not refresh FPL data"
            }
            store.saveError(message)
            throw t
        }
    }

    suspend fun loadPrivateLeagues(teamId: Int): List<LeagueChoice> = withContext(Dispatchers.IO) {
        readPrivateClassicLeagues(getJson("$base/entry/$teamId/"))
    }

    private fun readPrivateClassicLeagues(entry: JSONObject): List<LeagueChoice> {
        val classic = entry.optJSONObject("leagues")?.optJSONArray("classic") ?: JSONArray()
        val leagues = mutableListOf<LeagueChoice>()
        for (i in 0 until classic.length()) {
            val league = classic.getJSONObject(i)
            if (league.optString("league_type") != "x") continue
            if (league.optString("scoring", "c") != "c") continue
            leagues += LeagueChoice(
                id = league.optInt("id", 0),
                name = league.optString("name", "League"),
                rank = league.optInt("entry_rank", 0),
                lastRank = league.optInt("entry_last_rank", 0)
            )
        }
        return leagues.filter { it.id > 0 }
    }

    private fun selectLeague(leagues: List<LeagueChoice>, selectedId: Int?): LeagueChoice? {
        if (leagues.isEmpty()) return null
        return leagues.firstOrNull { it.id == selectedId } ?: leagues.first()
    }

    private fun buildRemainingFixtures(
        fixtureList: List<FixtureInfo>,
        scoringTeamIds: List<Int>,
        teamsById: Map<Int, TeamMeta>
    ): List<RemainingFixture> {
        return fixtureList
            .filter { !it.finished }
            .mapNotNull { fixture ->
                val count = scoringTeamIds.count { teamId ->
                    teamId == fixture.homeTeam || teamId == fixture.awayTeam
                }
                if (count <= 0) return@mapNotNull null
                val home = teamsById[fixture.homeTeam]
                val away = teamsById[fixture.awayTeam]
                val homeShort = home?.shortName ?: "HOME"
                val awayShort = away?.shortName ?: "AWAY"
                Pair(
                    fixture.kickoff,
                    RemainingFixture(
                        label = "$homeShort v $awayShort",
                        count = count,
                        homeCode = home?.code ?: 0,
                        awayCode = away?.code ?: 0,
                        homeShort = homeShort,
                        awayShort = awayShort
                    )
                )
            }
            .sortedBy { it.first }
            .map { it.second }
    }

    private fun currentGameweek(bootstrap: JSONObject): Int {
        val events = bootstrap.getJSONArray("events")
        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            if (event.optBoolean("is_current", false)) return event.getInt("id")
        }
        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            if (event.optBoolean("is_next", false)) return event.getInt("id")
        }
        return events.getJSONObject(events.length() - 1).getInt("id")
    }

    private fun findEvent(bootstrap: JSONObject, gameweek: Int): JSONObject? {
        val events = bootstrap.getJSONArray("events")
        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            if (event.optInt("id") == gameweek) return event
        }
        return null
    }

    private fun getJson(url: String): JSONObject = JSONObject(request(url))
    private fun getArray(url: String): JSONArray = JSONArray(request(url))

    private fun request(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 10_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "FPLPointsWidget/2.2")
        }
        return try {
            val code = connection.responseCode
            if (code !in 200..299) error("FPL request failed: HTTP $code")
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}

package com.stevehancock.fplwidget

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class FplRepository(private val context: Context) {
    private val base = "https://fantasy.premierleague.com/api"

    suspend fun refresh(): WidgetSnapshot = withContext(Dispatchers.IO) {
        val store = WidgetStore(context)
        val teamId = store.teamId ?: error("Enter your FPL Team ID first")

        try {
            val bootstrap = getJson("$base/bootstrap-static/")
            val gameweek = currentGameweek(bootstrap)
            val entry = getJson("$base/entry/$teamId/")
            val picks = getJson("$base/entry/$teamId/event/$gameweek/picks/")
            val live = getJson("$base/event/$gameweek/live/")
            val fixtures = getArray("$base/fixtures/?event=$gameweek")

            val playerTeam = HashMap<Int, Int>()
            val elements = bootstrap.getJSONArray("elements")
            for (i in 0 until elements.length()) {
                val player = elements.getJSONObject(i)
                playerTeam[player.getInt("id")] = player.getInt("team")
            }

            val livePoints = HashMap<Int, Int>()
            val liveElements = live.getJSONArray("elements")
            for (i in 0 until liveElements.length()) {
                val item = liveElements.getJSONObject(i)
                livePoints[item.getInt("id")] = item.getJSONObject("stats").optInt("total_points", 0)
            }

            val teamFixtures = HashMap<Int, MutableList<Boolean>>()
            for (i in 0 until fixtures.length()) {
                val fixture = fixtures.getJSONObject(i)
                val finished = fixture.optBoolean("finished", false)
                val home = fixture.getInt("team_h")
                val away = fixture.getInt("team_a")
                teamFixtures.getOrPut(home) { mutableListOf() }.add(finished)
                teamFixtures.getOrPut(away) { mutableListOf() }.add(finished)
            }

            var calculatedPoints = 0
            var scoringPlayers = 0
            var donePlayers = 0
            val picksArray = picks.getJSONArray("picks")
            for (i in 0 until picksArray.length()) {
                val pick = picksArray.getJSONObject(i)
                val elementId = pick.getInt("element")
                val multiplier = pick.optInt("multiplier", 0)
                if (multiplier <= 0) continue

                scoringPlayers++
                calculatedPoints += (livePoints[elementId] ?: 0) * multiplier

                val teamIdForPlayer = playerTeam[elementId]
                val status = teamIdForPlayer?.let { teamFixtures[it] }.orEmpty()
                if (status.isNotEmpty() && status.all { it }) {
                    donePlayers++
                }
            }

            val history = picks.optJSONObject("entry_history") ?: JSONObject()
            val transferCost = history.optInt("event_transfers_cost", 0)
            calculatedPoints -= transferCost

            val snapshot = WidgetSnapshot(
                teamName = entry.optString("name", "My FPL Team"),
                gameweek = gameweek,
                livePoints = calculatedPoints,
                overallRank = entry.optInt("summary_overall_rank", history.optInt("overall_rank", 0)),
                gameweekRank = history.optInt("rank", 0),
                playersDone = donePlayers,
                playersRemaining = (scoringPlayers - donePlayers).coerceAtLeast(0),
                updatedAt = System.currentTimeMillis(),
                error = null
            )
            store.save(snapshot)
            snapshot
        } catch (t: Throwable) {
            val message = when {
                t.message?.contains("404") == true -> "Team ID not found"
                t.message?.contains("429") == true -> "FPL is rate limiting updates"
                else -> t.message?.take(90) ?: "Could not refresh FPL data"
            }
            store.saveError(message)
            throw t
        }
    }

    private fun currentGameweek(bootstrap: JSONObject): Int {
        val events = bootstrap.getJSONArray("events")
        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            if (event.optBoolean("is_current", false)) return event.getInt("id")
        }
        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            if (event.optBoolean("is_next", false)) return event.getInt("id")
        }
        return events.getJSONObject(events.length() - 1).getInt("id")
    }

    private fun getJson(url: String): JSONObject = JSONObject(request(url))
    private fun getArray(url: String): JSONArray = JSONArray(request(url))

    private fun request(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 10_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "FPLPointsWidget/1.0")
        }
        return try {
            val code = connection.responseCode
            if (code !in 200..299) error("FPL request failed: HTTP $code")
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}

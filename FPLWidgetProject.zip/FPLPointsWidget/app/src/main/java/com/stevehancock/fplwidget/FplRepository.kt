package com.stevehancock.fplwidget

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.time.Instant


data class LeagueChoice(
    val id: Int,
    val name: String,
    val rank: Int,
    val lastRank: Int
)

private data class TeamMeta(
    val id: Int,
    val code: Int,
    val shortName: String
)

private data class FixtureInfo(
    val homeTeam: Int,
    val awayTeam: Int,
    val kickoff: String,
    val finished: Boolean
)

private data class RawLeagueStanding(
    val entryId: Int,
    val rank: Int,
    val lastRank: Int,
    val teamName: String,
    val eventPoints: Int,
    val totalPoints: Int
)

private data class LeagueFetch(
    val name: String,
    val rows: List<RawLeagueStanding>
)

class FplRepository(private val context: Context) {
    private val base = "https://fantasy.premierleague.com/api"

    companion object {
        // One picks request per mini-league member is required to calculate provisional live totals.
        // Keep this conservative so periodic widget refreshes do not hammer the FPL API.
        private const val MAX_LIVE_LEAGUE_MEMBERS = 20
        private const val MAX_LEAGUE_PAGES = 4
    }

    suspend fun refresh(): WidgetSnapshot = withContext(Dispatchers.IO) {
        val store = WidgetStore(context)
        val teamId = store.teamId ?: error("Enter your FPL Team ID first")

        try {
            val bootstrap = getJson("$base/bootstrap-static/")
            val gameweek = currentGameweek(bootstrap)
            val entry = getJson("$base/entry/$teamId/")
            val picks = getJson("$base/entry/$teamId/event/$gameweek/picks/")
            val live = getJson("$base/event/$gameweek/live/")
            val fixturesJson = getArray("$base/fixtures/?event=$gameweek")
            val history = getJson("$base/entry/$teamId/history/")

            val teamsById = readTeams(bootstrap)
            val playerTeams = HashMap<Int, Int>()
            val playerNames = HashMap<Int, String>()
            val elements = bootstrap.getJSONArray("elements")
            for (i in 0 until elements.length()) {
                val player = elements.getJSONObject(i)
                val id = player.getInt("id")
                playerTeams[id] = player.getInt("team")
                playerNames[id] = player.optString("web_name", "Player")
            }

            val livePointsByPlayer = readLivePoints(live)
            val fixtureList = readFixtures(fixturesJson)
            val teamFixtures = HashMap<Int, MutableList<FixtureInfo>>()
            fixtureList.forEach { fixture ->
                teamFixtures.getOrPut(fixture.homeTeam) { mutableListOf() }.add(fixture)
                teamFixtures.getOrPut(fixture.awayTeam) { mutableListOf() }.add(fixture)
            }

            var calculatedPoints = 0
            var scoringPlayers = 0
            var donePlayers = 0
            var captainName = "Captain"
            var captainPoints = 0
            var captainMultiplier = 2
            var captainTeamId = 0
            var captainTeamCode = 0
            var captainTeamShort = ""
            val scoringTeamCounts = linkedMapOf<Int, Int>()

            val picksArray = picks.getJSONArray("picks")
            for (i in 0 until picksArray.length()) {
                val pick = picksArray.getJSONObject(i)
                val elementId = pick.getInt("element")
                val multiplier = pick.optInt("multiplier", 0)

                if (pick.optBoolean("is_captain", false)) {
                    captainName = playerNames[elementId] ?: "Captain"
                    captainMultiplier = multiplier.coerceAtLeast(1)
                    captainPoints = (livePointsByPlayer[elementId] ?: 0) * captainMultiplier
                    captainTeamId = playerTeams[elementId] ?: 0
                    val captainTeam = teamsById[captainTeamId]
                    captainTeamCode = captainTeam?.code ?: 0
                    captainTeamShort = captainTeam?.shortName ?: ""
                }

                if (multiplier <= 0) continue

                scoringPlayers++
                calculatedPoints += (livePointsByPlayer[elementId] ?: 0) * multiplier

                val teamIdForPlayer = playerTeams[elementId]
                if (teamIdForPlayer != null) {
                    scoringTeamCounts[teamIdForPlayer] = (scoringTeamCounts[teamIdForPlayer] ?: 0) + 1
                    val statuses = teamFixtures[teamIdForPlayer].orEmpty()
                    if (statuses.isNotEmpty() && statuses.all { it.finished }) {
                        donePlayers++
                    }
                }
            }

            val entryHistory = picks.optJSONObject("entry_history") ?: JSONObject()
            calculatedPoints -= entryHistory.optInt("event_transfers_cost", 0)

            val event = findEvent(bootstrap, gameweek)
            val averagePoints = event?.optInt("average_entry_score", 0) ?: 0
            val previousOverallRank = previousOverallRank(history, gameweek, entry)

            val privateLeagues = readPrivateClassicLeagues(entry)
            val selectedLeague = selectLeague(privateLeagues, store.leagueId)
            if (store.leagueId == null && selectedLeague != null) {
                store.leagueId = selectedLeague.id
            }

            val fixtureCards = buildFixtureCards(
                fixtureList = fixtureList,
                scoringTeamCounts = scoringTeamCounts,
                teamsById = teamsById
            )

            val assets = AssetCache(context)
            fixtureCards.map { it.teamCode }
                .filter { it > 0 }
                .distinct()
                .forEach { assets.ensureBadge(it) }
            if (captainTeamCode > 0) {
                assets.ensureBadge(captainTeamCode)
                assets.ensureShirt(captainTeamCode, captainTeamId)
            }

            val leagueId = selectedLeague?.id ?: store.leagueId ?: 0
            var leagueName = selectedLeague?.name ?: "Your League"
            var leagueRank = selectedLeague?.rank ?: 0
            var leagueLastRank = selectedLeague?.lastRank ?: 0
            var leagueUsesLiveScores = false
            var leagueStandings = emptyList<LeagueStanding>()

            if (leagueId > 0) {
                try {
                    val leagueFetch = fetchLeagueStandings(leagueId)
                    if (leagueFetch.name.isNotBlank()) leagueName = leagueFetch.name
                    val calculated = calculateLeagueRows(
                        rows = leagueFetch.rows,
                        userEntryId = teamId,
                        gameweek = gameweek,
                        livePointsByPlayer = livePointsByPlayer
                    )
                    leagueStandings = calculated.first
                    leagueUsesLiveScores = calculated.second
                    val ownRow = leagueStandings.firstOrNull { it.isUser }
                    if (ownRow != null) {
                        leagueRank = ownRow.rank
                        leagueLastRank = ownRow.lastRank
                    }
                } catch (_: Throwable) {
                    // The main FPL widget remains useful even if a league endpoint is temporarily unavailable.
                }
            }

            val snapshot = WidgetSnapshot(
                teamName = entry.optString("name", "My FPL Team"),
                gameweek = gameweek,
                livePoints = calculatedPoints,
                averagePoints = averagePoints,
                overallRank = entry.optInt("summary_overall_rank", entryHistory.optInt("overall_rank", 0)),
                previousOverallRank = previousOverallRank,
                gameweekRank = entryHistory.optInt("rank", entry.optInt("summary_event_rank", 0)),
                playersDone = donePlayers,
                playersRemaining = (scoringPlayers - donePlayers).coerceAtLeast(0),
                captainName = captainName,
                captainPoints = captainPoints,
                captainMultiplier = captainMultiplier,
                captainTeamId = captainTeamId,
                captainTeamCode = captainTeamCode,
                captainTeamShort = captainTeamShort,
                leagueId = leagueId,
                leagueName = leagueName,
                leagueRank = leagueRank,
                leagueLastRank = leagueLastRank,
                leagueUsesLiveScores = leagueUsesLiveScores,
                fixtures = fixtureCards,
                leagueStandings = leagueStandings,
                updatedAt = System.currentTimeMillis(),
                error = null
            )
            store.save(snapshot)
            snapshot
        } catch (t: Throwable) {
            val message = when {
                t.message?.contains("404") == true -> "Team ID not found"
                t.message?.contains("429") == true -> "FPL is rate limiting updates"
                else -> t.message?.take(90) ?: "Could not refresh FPL data"
            }
            store.saveError(message)
            throw t
        }
    }

    suspend fun loadPrivateLeagues(teamId: Int): List<LeagueChoice> = withContext(Dispatchers.IO) {
        readPrivateClassicLeagues(getJson("$base/entry/$teamId/"))
    }

    private fun readTeams(bootstrap: JSONObject): Map<Int, TeamMeta> {
        val result = HashMap<Int, TeamMeta>()
        val teams = bootstrap.getJSONArray("teams")
        for (i in 0 until teams.length()) {
            val team = teams.getJSONObject(i)
            val id = team.getInt("id")
            result[id] = TeamMeta(
                id = id,
                code = team.optInt("code", id),
                shortName = team.optString("short_name", "T$id")
            )
        }
        return result
    }

    private fun readLivePoints(live: JSONObject): Map<Int, Int> {
        val result = HashMap<Int, Int>()
        val elements = live.getJSONArray("elements")
        for (i in 0 until elements.length()) {
            val item = elements.getJSONObject(i)
            result[item.getInt("id")] = item.getJSONObject("stats").optInt("total_points", 0)
        }
        return result
    }

    private fun readFixtures(fixtures: JSONArray): List<FixtureInfo> {
        val result = mutableListOf<FixtureInfo>()
        for (i in 0 until fixtures.length()) {
            val fixture = fixtures.getJSONObject(i)
            result += FixtureInfo(
                homeTeam = fixture.getInt("team_h"),
                awayTeam = fixture.getInt("team_a"),
                kickoff = fixture.optString("kickoff_time", ""),
                finished = fixture.optBoolean("finished", false) || fixture.optBoolean("finished_provisional", false)
            )
        }
        return result
    }

    private fun buildFixtureCards(
        fixtureList: List<FixtureInfo>,
        scoringTeamCounts: Map<Int, Int>,
        teamsById: Map<Int, TeamMeta>
    ): List<FixtureCard> {
        val result = mutableListOf<FixtureCard>()
        fixtureList.forEach { fixture ->
            val ownedTeams = listOf(fixture.homeTeam, fixture.awayTeam)
            ownedTeams.forEach ownedTeamLoop@ { ownedTeamId ->
                val count = scoringTeamCounts[ownedTeamId] ?: 0
                if (count <= 0) return@ownedTeamLoop
                val isHome = ownedTeamId == fixture.homeTeam
                val opponentId = if (isHome) fixture.awayTeam else fixture.homeTeam
                val team = teamsById[ownedTeamId]
                val opponent = teamsById[opponentId]
                result += FixtureCard(
                    teamId = ownedTeamId,
                    teamCode = team?.code ?: 0,
                    teamShort = team?.shortName ?: "TEAM",
                    opponentShort = opponent?.shortName ?: "OPP",
                    homeAway = if (isHome) "H" else "A",
                    count = count,
                    kickoffAt = parseKickoff(fixture.kickoff),
                    finished = fixture.finished
                )
            }
        }
        // Show fixtures that still matter first. Within each group, place the latest
        // kickoff on the left so paging moves from latest to older fixtures.
        return result.sortedWith(
            compareBy<FixtureCard> { it.finished }
                .thenByDescending { it.kickoffAt }
                .thenBy { it.teamShort }
        )
    }

    private fun fetchLeagueStandings(leagueId: Int): LeagueFetch {
        val rows = mutableListOf<RawLeagueStanding>()
        var page = 1
        var hasNext = true
        var leagueName = ""

        while (hasNext && page <= MAX_LEAGUE_PAGES) {
            val response = getJson("$base/leagues-classic/$leagueId/standings/?page_standings=$page")
            if (leagueName.isBlank()) {
                leagueName = response.optJSONObject("league")?.optString("name", "") ?: ""
            }
            val standings = response.optJSONObject("standings") ?: break
            val results = standings.optJSONArray("results") ?: JSONArray()
            for (i in 0 until results.length()) {
                val row = results.getJSONObject(i)
                rows += RawLeagueStanding(
                    entryId = row.optInt("entry", 0),
                    rank = row.optInt("rank", i + 1),
                    lastRank = row.optInt("last_rank", 0),
                    teamName = row.optString("entry_name", "Team"),
                    eventPoints = row.optInt("event_total", 0),
                    totalPoints = row.optInt("total", 0)
                )
            }
            hasNext = standings.optBoolean("has_next", false)
            page++
        }
        return LeagueFetch(leagueName, rows.filter { it.entryId > 0 })
    }

    private fun calculateLeagueRows(
        rows: List<RawLeagueStanding>,
        userEntryId: Int,
        gameweek: Int,
        livePointsByPlayer: Map<Int, Int>
    ): Pair<List<LeagueStanding>, Boolean> {
        if (rows.isEmpty()) return emptyList<LeagueStanding>() to false

        if (rows.size <= MAX_LIVE_LEAGUE_MEMBERS) {
            try {
                val provisional = rows.map { row ->
                    val picks = getJson("$base/entry/${row.entryId}/event/$gameweek/picks/")
                    val liveGw = calculateLiveEntryPoints(picks, livePointsByPlayer)
                    val totalBeforeGw = (row.totalPoints - row.eventPoints).coerceAtLeast(0)
                    Triple(row, liveGw, totalBeforeGw + liveGw)
                }.sortedWith(
                    compareByDescending<Triple<RawLeagueStanding, Int, Int>> { it.third }
                        .thenByDescending { it.second }
                        .thenBy { it.first.teamName.lowercase() }
                )

                val result = provisional.mapIndexed { index, item ->
                    LeagueStanding(
                        entryId = item.first.entryId,
                        rank = index + 1,
                        lastRank = item.first.lastRank,
                        teamName = item.first.teamName,
                        eventPoints = item.second,
                        totalPoints = item.third,
                        isUser = item.first.entryId == userEntryId
                    )
                }
                return result to true
            } catch (_: Throwable) {
                // Fall through to the official league data so one failed member request does not break refresh.
            }
        }

        return rows.sortedBy { it.rank }.map { row ->
            LeagueStanding(
                entryId = row.entryId,
                rank = row.rank,
                lastRank = row.lastRank,
                teamName = row.teamName,
                eventPoints = row.eventPoints,
                totalPoints = row.totalPoints,
                isUser = row.entryId == userEntryId
            )
        } to false
    }

    private fun calculateLiveEntryPoints(picks: JSONObject, livePointsByPlayer: Map<Int, Int>): Int {
        var points = 0
        val rows = picks.optJSONArray("picks") ?: JSONArray()
        for (i in 0 until rows.length()) {
            val pick = rows.getJSONObject(i)
            val multiplier = pick.optInt("multiplier", 0)
            if (multiplier <= 0) continue
            points += (livePointsByPlayer[pick.optInt("element", 0)] ?: 0) * multiplier
        }
        points -= picks.optJSONObject("entry_history")?.optInt("event_transfers_cost", 0) ?: 0
        return points
    }

    private fun readPrivateClassicLeagues(entry: JSONObject): List<LeagueChoice> {
        val classic = entry.optJSONObject("leagues")?.optJSONArray("classic") ?: JSONArray()
        val leagues = mutableListOf<LeagueChoice>()
        for (i in 0 until classic.length()) {
            val league = classic.getJSONObject(i)
            if (league.optString("league_type") != "x") continue
            if (league.optString("scoring", "c") != "c") continue
            leagues += LeagueChoice(
                id = league.optInt("id", 0),
                name = league.optString("name", "League"),
                rank = league.optInt("entry_rank", 0),
                lastRank = league.optInt("entry_last_rank", 0)
            )
        }
        return leagues.filter { it.id > 0 }
    }

    private fun selectLeague(leagues: List<LeagueChoice>, selectedId: Int?): LeagueChoice? {
        if (leagues.isEmpty()) return selectedId?.let { LeagueChoice(it, "Your League", 0, 0) }
        return leagues.firstOrNull { it.id == selectedId }
            ?: if (selectedId != null) LeagueChoice(selectedId, "Your League", 0, 0) else leagues.first()
    }

    private fun previousOverallRank(history: JSONObject, gameweek: Int, entry: JSONObject): Int {
        val currentHistory = history.optJSONArray("current") ?: JSONArray()
        for (i in currentHistory.length() - 1 downTo 0) {
            val row = currentHistory.getJSONObject(i)
            if (row.optInt("event", 0) < gameweek) {
                return row.optInt("overall_rank", 0)
            }
        }
        return entry.optInt("summary_overall_rank", 0)
    }

    private fun currentGameweek(bootstrap: JSONObject): Int {
        val events = bootstrap.getJSONArray("events")
        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            if (event.optBoolean("is_current", false)) return event.getInt("id")
        }
        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            if (event.optBoolean("is_next", false)) return event.getInt("id")
        }
        return events.getJSONObject(events.length() - 1).getInt("id")
    }

    private fun findEvent(bootstrap: JSONObject, gameweek: Int): JSONObject? {
        val events = bootstrap.getJSONArray("events")
        for (i in 0 until events.length()) {
            val event = events.getJSONObject(i)
            if (event.optInt("id") == gameweek) return event
        }
        return null
    }

    private fun parseKickoff(raw: String): Long = try {
        if (raw.isBlank()) 0L else Instant.parse(raw).toEpochMilli()
    } catch (_: Throwable) {
        0L
    }

    private fun getJson(url: String): JSONObject = JSONObject(request(url))
    private fun getArray(url: String): JSONArray = JSONArray(request(url))

    private fun request(url: String): String {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 10_000
            readTimeout = 10_000
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "FPLPointsWidget/3.0")
        }
        return try {
            val code = connection.responseCode
            if (code !in 200..299) error("FPL request failed: HTTP $code")
            connection.inputStream.bufferedReader().use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }
}

package com.stevehancock.fplwidget

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.glance.appwidget.updateAll
import androidx.activity.ComponentActivity
import androidx.lifecycle.lifecycleScope
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var teamIdInput: EditText
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())

        WidgetStore(this).teamId?.let { teamIdInput.setText(it.toString()) }
    }

    private fun buildUi(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(40), dp(24), dp(24))
            setBackgroundColor(Color.WHITE)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        root.addView(TextView(this).apply {
            text = "FPL Points Widget"
            textSize = 28f
            setTextColor(Color.rgb(23, 19, 38))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = "Enter your Fantasy Premier League Team ID once. The widget will then track your current gameweek points from your Android home screen."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(10), 0, dp(24))
        })

        root.addView(TextView(this).apply {
            text = "FPL Team ID"
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        teamIdInput = EditText(this).apply {
            hint = "e.g. 1234567"
            textSize = 20f
            inputType = InputType.TYPE_CLASS_NUMBER
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        root.addView(teamIdInput, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(56)
        ).apply { topMargin = dp(6) })

        val saveButton = Button(this).apply {
            text = "SAVE & REFRESH"
            textSize = 14f
            setOnClickListener { saveAndRefresh() }
        }
        root.addView(saveButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(56)
        ).apply { topMargin = dp(16) })

        statusText = TextView(this).apply {
            text = "After saving: hold your home screen → Widgets → FPL Points Widget."
            textSize = 14f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.START
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(statusText)

        root.addView(TextView(this).apply {
            text = "Tip: your Team ID is the number in the FPL website address when viewing your team."
            textSize = 12f
            setTextColor(Color.GRAY)
            setPadding(0, dp(22), 0, 0)
        })

        return root
    }

    private fun saveAndRefresh() {
        val id = teamIdInput.text.toString().trim().toIntOrNull()
        if (id == null || id <= 0) {
            Toast.makeText(this, "Enter a valid Team ID", Toast.LENGTH_SHORT).show()
            return
        }

        WidgetStore(this).teamId = id
        statusText.text = "Refreshing FPL data…"

        lifecycleScope.launch {
            try {
                val data = FplRepository(this@MainActivity).refresh()
                FplWidget().updateAll(this@MainActivity)
                scheduleUpdates()
                statusText.text = "Connected: ${data.teamName} • GW${data.gameweek} • ${data.livePoints} points"
            } catch (t: Throwable) {
                FplWidget().updateAll(this@MainActivity)
                statusText.text = "Could not load team: ${t.message ?: "Unknown error"}"
            }
        }
    }

    private fun scheduleUpdates() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = PeriodicWorkRequestBuilder<RefreshWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "fpl-widget-refresh",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

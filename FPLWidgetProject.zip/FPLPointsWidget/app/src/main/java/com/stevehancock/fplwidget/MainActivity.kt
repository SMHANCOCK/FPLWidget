package com.stevehancock.fplwidget

import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.glance.appwidget.updateAll
import androidx.lifecycle.lifecycleScope
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    private lateinit var teamIdInput: EditText
    private lateinit var leagueIdInput: EditText
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())

        val store = WidgetStore(this)
        store.teamId?.let { teamIdInput.setText(it.toString()) }
        store.leagueId?.let { leagueIdInput.setText(it.toString()) }
    }

    private fun buildUi(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(36), dp(24), dp(24))
            setBackgroundColor(Color.rgb(10, 16, 50))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        root.addView(TextView(this).apply {
            text = "FPL Points Widget V2.2"
            textSize = 28f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })

        root.addView(TextView(this).apply {
            text = "Live points, average, captain, remaining fixtures, overall rank movement and your mini-league position."
            textSize = 14f
            setTextColor(Color.rgb(184, 192, 224))
            setPadding(0, dp(10), 0, dp(24))
        })

        root.addView(label("FPL Team ID"))
        teamIdInput = numberInput("e.g. 1234567")
        root.addView(teamIdInput, fieldLayout())

        root.addView(label("Mini-League ID (optional)").apply {
            setPadding(0, dp(18), 0, 0)
        })
        leagueIdInput = numberInput("Leave blank to use your first private league")
        root.addView(leagueIdInput, fieldLayout())

        root.addView(TextView(this).apply {
            text = "League ID is the number in the FPL league URL, for example /leagues/123456/standings/c."
            textSize = 11f
            setTextColor(Color.rgb(142, 152, 196))
            setPadding(0, dp(8), 0, 0)
        })

        val saveButton = Button(this).apply {
            text = "SAVE & REFRESH"
            textSize = 14f
            setOnClickListener { saveAndRefresh() }
        }
        root.addView(saveButton, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            dp(56)
        ).apply { topMargin = dp(20) })

        statusText = TextView(this).apply {
            text = "You can change these IDs at any time. Tap the pencil icon on the widget to reopen this screen."
            textSize = 13f
            setTextColor(Color.rgb(184, 192, 224))
            gravity = Gravity.START
            setPadding(0, dp(18), 0, 0)
        }
        root.addView(statusText)

        root.addView(TextView(this).apply {
            text = "Refresh: tap the circular arrow on the widget. Android also refreshes in the background roughly every 15 minutes when allowed."
            textSize = 11f
            setTextColor(Color.rgb(142, 152, 196))
            setPadding(0, dp(22), 0, 0)
        })

        return root
    }

    private fun label(textValue: String): TextView = TextView(this).apply {
        text = textValue
        textSize = 13f
        setTextColor(Color.rgb(184, 192, 224))
        setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun numberInput(hintValue: String): EditText = EditText(this).apply {
        hint = hintValue
        textSize = 18f
        inputType = InputType.TYPE_CLASS_NUMBER
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(112, 124, 170))
        setPadding(dp(14), dp(10), dp(14), dp(10))
    }

    private fun fieldLayout() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        dp(56)
    ).apply { topMargin = dp(6) }

    private fun saveAndRefresh() {
        val teamId = teamIdInput.text.toString().trim().toIntOrNull()
        if (teamId == null || teamId <= 0) {
            Toast.makeText(this, "Enter a valid Team ID", Toast.LENGTH_SHORT).show()
            return
        }

        val leagueText = leagueIdInput.text.toString().trim()
        val leagueId = if (leagueText.isBlank()) null else leagueText.toIntOrNull()
        if (leagueText.isNotBlank() && (leagueId == null || leagueId <= 0)) {
            Toast.makeText(this, "Enter a valid League ID or leave it blank", Toast.LENGTH_SHORT).show()
            return
        }

        val store = WidgetStore(this)
        store.teamId = teamId
        store.leagueId = leagueId
        statusText.text = "Refreshing FPL data..."

        lifecycleScope.launch {
            try {
                val data = FplRepository(this@MainActivity).refresh()
                FplWidget().updateAll(this@MainActivity)
                scheduleUpdates()
                if (leagueIdInput.text.toString().isBlank() && data.leagueId > 0) {
                    leagueIdInput.setText(data.leagueId.toString())
                }
                val leagueTextOut = if (data.leagueRank > 0) {
                    " • ${data.leagueName}: ${ordinalForStatus(data.leagueRank)}"
                } else {
                    ""
                }
                statusText.text = "Connected: ${data.teamName} • GW${data.gameweek} • ${data.livePoints} live pts$leagueTextOut"
            } catch (t: Throwable) {
                FplWidget().updateAll(this@MainActivity)
                statusText.text = "Could not load team: ${t.message ?: "Unknown error"}"
            }
        }
    }

    private fun scheduleUpdates() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = PeriodicWorkRequestBuilder<RefreshWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "fpl-widget-refresh",
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    private fun ordinalForStatus(value: Int): String {
        val mod100 = value % 100
        val suffix = if (mod100 in 11..13) "th" else when (value % 10) {
            1 -> "st"
            2 -> "nd"
            3 -> "rd"
            else -> "th"
        }
        return "$value$suffix"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

package com.stevehancock.fplwidget

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity

class LeagueActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
    }

    private fun buildUi(): ScrollView {
        val snapshot = WidgetStore(this).load()
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(8, 13, 35))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(24), dp(18), dp(24))
        }
        scroll.addView(root, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        root.addView(TextView(this).apply {
            text = snapshot?.leagueName ?: "FPL Mini League"
            textSize = 26f
            setTextColor(Color.WHITE)
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = if (snapshot?.leagueUsesLiveScores == true) "Live provisional standings" else "Official FPL standings"
            textSize = 13f
            setTextColor(if (snapshot?.leagueUsesLiveScores == true) Color.rgb(0, 255, 135) else Color.rgb(150, 160, 195))
            setPadding(0, dp(4), 0, dp(18))
        })

        root.addView(headerRow())
        snapshot?.leagueStandings.orEmpty().forEach { root.addView(standingRow(it)) }
        if (snapshot?.leagueStandings.isNullOrEmpty()) {
            root.addView(TextView(this).apply {
                text = "No cached standings yet. Refresh the widget first."
                textSize = 14f
                setTextColor(Color.rgb(180, 190, 220))
                setPadding(0, dp(18), 0, 0)
            })
        }
        return scroll
    }

    private fun headerRow(): LinearLayout = rowContainer(false).apply {
        addView(cell("#", 0.7f, true))
        addView(cell("Team", 3.8f, true))
        addView(cell("GW", 1f, true, Gravity.END))
        addView(cell("Total", 1.2f, true, Gravity.END))
        addView(cell("Move", 1f, true, Gravity.END))
    }

    private fun standingRow(row: LeagueStanding): LinearLayout {
        val movement = if (row.rank > 0 && row.lastRank > 0) row.lastRank - row.rank else 0
        val movementText = when {
            movement > 0 -> "▲ $movement"
            movement < 0 -> "▼ ${-movement}"
            else -> "•"
        }
        val movementColor = when {
            movement > 0 -> Color.rgb(0, 255, 135)
            movement < 0 -> Color.rgb(255, 77, 115)
            else -> Color.rgb(140, 150, 180)
        }
        return rowContainer(row.isUser).apply {
            addView(cell(row.rank.toString(), 0.7f, row.isUser))
            addView(cell(row.teamName, 3.8f, row.isUser))
            addView(cell(row.eventPoints.toString(), 1f, row.isUser, Gravity.END))
            addView(cell(row.totalPoints.toString(), 1.2f, row.isUser, Gravity.END))
            addView(cell(movementText, 1f, true, Gravity.END, movementColor))
        }
    }

    private fun rowContainer(highlight: Boolean): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(8), dp(9), dp(8), dp(9))
        setBackgroundColor(if (highlight) Color.rgb(14, 75, 70) else Color.TRANSPARENT)
    }

    private fun cell(
        value: String,
        weight: Float,
        bold: Boolean,
        gravityValue: Int = Gravity.START,
        color: Int = Color.WHITE
    ): TextView = TextView(this).apply {
        text = value
        textSize = 13f
        setTextColor(color)
        gravity = gravityValue
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weight)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}

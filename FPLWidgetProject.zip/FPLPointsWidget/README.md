# FPL Points Widget V2

Android home-screen widget for Fantasy Premier League.

## V2 dashboard

- Large live gameweek points
- Current gameweek average and +/- vs average
- Captain name and captain points
- Players done / players left
- Remaining fixtures grouped by fixture with player counts
- Overall rank and movement vs previous gameweek
- Selected private classic mini-league position and movement
- Manual refresh button
- Background refresh via WorkManager

## Setup

Open the app and enter:

1. FPL Team ID - required.
2. Mini-League ID - optional. Leave blank and V2 picks the first private classic league attached to the team. If you want a specific league, use the number in the FPL URL `/leagues/123456/standings/c`.

Then tap **SAVE & REFRESH** and add the widget to the home screen.

For the intended V2 dashboard, resize the widget to full home-screen width and roughly two rows high.

## Notes

The widget uses public Fantasy Premier League endpoints. It does not need an FPL password.

Live points are calculated from the current public picks/live data and include captain multipliers and transfer hits. FPL can delay some official rank/average values during a live gameweek.

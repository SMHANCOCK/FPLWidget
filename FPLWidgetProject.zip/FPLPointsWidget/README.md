# FPL Points Widget V3

Android home-screen widget for Fantasy Premier League. V3 keeps the working V2.2 FPL configuration, API, refresh and signing setup, then extends the native widget UI toward the supplied target dashboard.

## Existing project responsibilities inspected before the V3 changes

- `FplWidget.kt` - Glance/AppWidget UI, edit/refresh actions and widget rendering.
- `FplRepository.kt` - public FPL API calls and live gameweek calculations.
- `WidgetStore.kt` - Team ID, League ID and cached widget snapshot in SharedPreferences.
- `MainActivity.kt` - configuration screen and Save & Refresh flow.
- `RefreshWorker.kt` - periodic WorkManager refresh.
- `FplWidgetReceiver.kt` - AppWidget provider/receiver.
- `AssetCache.kt` - club badge and shirt image cache.
- `fpl_widget_info.xml` - widget size/resize metadata.

## V3 dashboard

- Dark navy FPL-style native widget UI.
- Permanent FPL logo, FPL label and a single GW label in the header.
- Team name, overall rank and rank movement in the header.
- Players done/left, updated time, permanent edit button and manual refresh.
- Dominant live GW points card.
- Dedicated official current-GW average card.
- Dedicated live points vs average card with green/red state.
- Captain card with actual cached club shirt where available, C/TC chip and multiplied live points.
- Players-by-fixture cards with club badge, opponent, H/A, owned scoring-player count, real fixture date and kickoff time.
- Completed fixture counts are muted; unfinished/current fixture counts are FPL green.
- Scrollable native mini-league table inside the widget using Glance `LazyColumn`.
- Mini-league rows show rank, team, GW points, total points and movement.
- The configured user's league row is highlighted.
- `View league` opens a cached full-league screen inside the app.
- For mini leagues of up to 20 entries, V3 attempts provisional live GW/total scoring by combining each member's picks with the current FPL live endpoint. Larger leagues use official FPL standings to avoid excessive API calls.
- Existing background refresh and manual refresh are retained.

## Responsive behaviour

The target design is extremely dense for a phone home-screen widget. V3 uses `SizeMode.Exact` and responds to the actual launcher widget size.

- Normal full-width phone widget: target-style left dashboard plus a narrow scrollable league table on the right.
- Wider widget/tablet/landscape: larger target-style cards and a wider league table.
- Very narrow widget: the layout drops into a simplified safe state rather than overlapping or shrinking everything into unreadable text.

## Setup

Open the app and enter:

1. FPL Team ID - required.
2. Mini-League ID - optional. Leave blank to use the first private classic league attached to the team.

Tap **SAVE & REFRESH**. The existing permanent signing setup means V3 should install directly over V2.2.

The pencil button is always visible and opens the configuration activity. Opening the app from the launcher also opens the same configuration screen.
